jQuery(document).ready(function($) {
    // Handle Login Form Submission
    $('#ccpp-login-form').on('submit', function(e) {
        e.preventDefault();
        var $form = $(this);
        var $message = $('#ccpp-login-message');

        $.ajax({
            url: ccpp_auth.ajax_url,
            type: 'POST',
            data: {
                action: 'ccpp_login',
                nonce: ccpp_auth.nonce,
                username: $form.find('input[name="username"]').val(),
                password: $form.find('input[name="password"]').val()
            },
            beforeSend: function() {
                $form.find('input[type="submit"]').prop('disabled', true);
                $message.addClass('hidden');
            },
            success: function(response) {
                if (response.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Success',
                        text: 'Login successful! Redirecting...',
                        timer: 1500,
                        showConfirmButton: false
                    }).then(function() {
                        window.location.href = response.data.redirect;
                    });
                } else {
                    var message = response.data.message;
                    var type = response.data.type;

                    if (type === 'unverified') {
                        Swal.fire({
                            icon: 'warning',
                            title: 'Email Verification Required',
                            text: message,
                            confirmButtonText: 'Resend Verification Email',
                            showCancelButton: true
                        }).then(function(result) {
                            if (result.isConfirmed) {
                                // Logic to resend verification email (can be added later)
                                Swal.fire('Resend Email', 'Verification email resent.', 'info');
                            }
                        });
                    } else if (type === 'invalid_credentials') {
                        Swal.fire({
                            icon: 'error',
                            title: 'Invalid Credentials',
                            text: message
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: message
                        });
                    }
                }
            },
            error: function() {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'An error occurred. Please try again.'
                });
            },
            complete: function() {
                $form.find('input[type="submit"]').prop('disabled', false);
            }
        });
    });

    // Handle Registration Form Submission
    $('#ccpp-register-form').on('submit', function(e) {
        e.preventDefault();
        var $form = $(this);
        var $message = $('#ccpp-register-message');

        $.ajax({
            url: ccpp_auth.ajax_url,
            type: 'POST',
            data: {
                action: 'ccpp_register',
                nonce: ccpp_auth.nonce,
                username: $form.find('input[name="username"]').val(),
                email: $form.find('input[name="email"]').val(),
                password: $form.find('input[name="password"]').val(),
                confirm_password: $form.find('input[name="confirm_password"]').val(),
                first_name: $form.find('input[name="first_name"]').val(),
                last_name: $form.find('input[name="last_name"]').val()
            },
            beforeSend: function() {
                $form.find('input[type="submit"]').prop('disabled', true);
                $message.addClass('hidden');
            },
            success: function(response) {
                if (response.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Success',
                        text: response.data.message,
                        timer: 3000,
                        showConfirmButton: false
                    }).then(function() {
                        if (response.data.redirect) {
                            window.location.href = response.data.redirect;
                        }
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: response.data.message
                    });
                }
            },
            error: function() {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'An error occurred. Please try again.'
                });
            },
            complete: function() {
                $form.find('input[type="submit"]').prop('disabled', false);
            }
        });
    });

    // Handle Forgot Password Form Submission
    $('#ccpp-forgot-password-form').on('submit', function(e) {
        e.preventDefault();
        var $form = $(this);
        var $message = $('#ccpp-forgot-password-message');

        $.ajax({
            url: ccpp_auth.ajax_url,
            type: 'POST',
            data: {
                action: 'ccpp_forgot_password',
                nonce: ccpp_auth.nonce,
                email: $form.find('input[name="email"]').val()
            },
            beforeSend: function() {
                $form.find('input[type="submit"]').prop('disabled', true);
                $message.addClass('hidden');
            },
            success: function(response) {
                if (response.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Success',
                        text: response.data.message,
                        timer: 3000,
                        showConfirmButton: false
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: response.data.message
                    });
                }
            },
            error: function() {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'An error occurred. Please try again.'
                });
            },
            complete: function() {
                $form.find('input[type="submit"]').prop('disabled', false);
            }
        });
    });

    // Handle User Profile Form Submission
    $('#ccpp-user-profile-form').on('submit', function(e) {
        e.preventDefault();
        var $form = $(this);
        var $message = $('#ccpp-user-profile-message');

        $.ajax({
            url: ccpp_auth.ajax_url,
            type: 'POST',
            data: {
                action: 'ccpp_update_profile',
                nonce: ccpp_auth.nonce,
                first_name: $form.find('input[name="first_name"]').val(),
                last_name: $form.find('input[name="last_name"]').val(),
                email: $form.find('input[name="email"]').val(),
                new_password: $form.find('input[name="new_password"]').val(),
                confirm_password: $form.find('input[name="confirm_password"]').val()
            },
            beforeSend: function() {
                $form.find('input[type="submit"]').prop('disabled', true);
                $message.addClass('hidden');
            },
            success: function(response) {
                if (response.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Success',
                        text: response.data.message,
                        timer: 1500,
                        showConfirmButton: false
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: response.data.message
                    });
                }
            },
            error: function() {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'An error occurred. Please try again.'
                });
            },
            complete: function() {
                $form.find('input[type="submit"]').prop('disabled', false);
            }
        });
    });

    // Handle Password Reset Form Submission
    $('#ccpp-password-reset-form').on('submit', function(e) {
        e.preventDefault();
        var $form = $(this);
        var $message = $('#ccpp-password-reset-message');

        $.ajax({
            url: ccpp_auth.ajax_url,
            type: 'POST',
            data: {
                action: 'ccpp_update_account',
                nonce: ccpp_auth.nonce,
                new_password: $form.find('input[name="new_password"]').val(),
                confirm_password: $form.find('input[name="confirm_password"]').val()
            },
            beforeSend: function() {
                $form.find('input[type="submit"]').prop('disabled', true);
                $message.addClass('hidden');
            },
            success: function(response) {
                if (response.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Success',
                        text: response.data.message,
                        timer: 1500,
                        showConfirmButton: false
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: response.data.message
                    });
                }
            },
            error: function() {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'An error occurred. Please try again.'
                });
            },
            complete: function() {
                $form.find('input[type="submit"]').prop('disabled', false);
            }
        });
    });
});