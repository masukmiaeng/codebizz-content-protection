jQuery(document).ready(function($) {
    // Prevent right-click if enabled
    if (ccpp_frontend.right_click === '1') {
        $(document).on('contextmenu', function(e) {
            if (ccpp_frontend.is_admin_dashboard !== '1') {
                alert(ccpp_frontend.copy_alert);
                return false;
            }
        });
    }

    // Prevent keyboard shortcuts if enabled
    if (ccpp_frontend.keyboard_shortcuts === '1') {
        $(document).on('keydown', function(e) {
            if (ccpp_frontend.is_admin_dashboard !== '1') {
                if (e.ctrlKey || e.metaKey) {
                    if (['c', 'x', 'u', 's', 'p'].includes(e.key.toLowerCase())) {
                        alert(ccpp_frontend.copy_alert);
                        e.preventDefault();
                        return false;
                    }
                }
            }
        });
    }

    // Prevent text selection if enabled
    if (ccpp_frontend.selection_block === '1') {
        $(document).on('selectstart', function(e) {
            if (ccpp_frontend.is_admin_dashboard !== '1') {
                e.preventDefault();
                return false;
            }
        });
    }

    // Protect images if enabled
    if (ccpp_frontend.image_protection === '1') {
        $('img').on('dragstart', function(e) {
            if (ccpp_frontend.is_admin_dashboard !== '1') {
                e.preventDefault();
                return false;
            }
        }).on('contextmenu', function(e) {
            if (ccpp_frontend.is_admin_dashboard !== '1') {
                alert(ccpp_frontend.copy_alert);
                e.preventDefault();
                return false;
            }
        });
    }

    // Handle password form submission
    $(document).on('submit', '[id^="ccpp-password-form-"]', function(e) {
        e.preventDefault();
        var $form = $(this);
        var post_id = $form.find('input[name="post_id"]').val();
        var password = $form.find('input[name="password"]').val();
        var $message = $('#ccpp-password-message-' + post_id);

        $.ajax({
            url: ccpp_frontend.ajax_url,
            type: 'POST',
            data: {
                action: 'ccpp_verify_password',
                nonce: ccpp_frontend.nonce,
                post_id: post_id,
                password: password
            },
            success: function(response) {
                $message.removeClass('hidden');
                if (response.success) {
                    $message.removeClass('bg-red-100 text-red-500').addClass('bg-green-100 text-green-500').text(response.data.message);
                    location.reload();
                } else {
                    $message.removeClass('bg-green-100 text-green-500').addClass('bg-red-100 text-red-500').text(response.data.message);
                }
            },
            error: function(xhr, status, error) {
                console.error('Password verification error:', error);
                $message.removeClass('hidden bg-green-100 text-green-500').addClass('bg-red-100 text-red-500').text('An error occurred.');
            }
        });
    });
});