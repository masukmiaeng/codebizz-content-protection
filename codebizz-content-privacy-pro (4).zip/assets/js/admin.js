jQuery(document).ready(function($) {
    // Toggle protection status
    window.toggleProtection = function() {
        $.ajax({
            url: ccpp_admin.ajax_url,
            type: 'POST',
            data: {
                action: 'ccpp_toggle_protection',
                nonce: ccpp_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    var status = response.data.status;
                    $('#ccpp-protection-status').text(response.data.message);
                    $('#ccpp-protection-toggle').text(status === '1' ? 'Disable' : 'Enable');
                } else {
                    alert('Failed to toggle protection: ' + (response.data.message || 'Unknown error'));
                }
            },
            error: function(xhr, status, error) {
                console.error('Toggle protection error:', error);
                alert('An error occurred while toggling protection.');
            }
        });
    };

    // Handle user actions
    $('.ccpp-approve-user').on('click', function(e) {
        e.preventDefault();
        if (confirm('Are you sure you want to approve this user?')) {
            window.location.href = $(this).attr('href');
        }
    });

    $('.ccpp-reject-user').on('click', function(e) {
        e.preventDefault();
        if (confirm('Are you sure you want to reject this user?')) {
            window.location.href = $(this).attr('href');
        }
    });

    $('.ccpp-delete-user').on('click', function(e) {
        e.preventDefault();
        if (confirm('Are you sure you want to delete this user?')) {
            window.location.href = $(this).attr('href');
        }
    });
});