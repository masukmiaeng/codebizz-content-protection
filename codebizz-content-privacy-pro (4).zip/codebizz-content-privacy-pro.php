<?php
/*
Plugin Name: Codebizz Content Privacy Pro (CCPP)
Version: 1.0.18
Description: A WordPress plugin to protect content with privacy, membership, content locker, screenshot protection, login, registration, user profile, account management, and user history features using PayPal REST API.
Author: Masuk Mia
Author URI: https://codebizz.net
Text Domain: ccpp
Domain Path: /languages
*/

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define constants
define('CCPP_VERSION', '1.0.18');
define('CCPP_PATH', plugin_dir_path(__FILE__));
define('CCPP_URL', plugin_dir_url(__FILE__));
define('CCPP_BASENAME', plugin_basename(__FILE__));

// Check PHP version
if (version_compare(PHP_VERSION, '7.4.0', '<')) {
    add_action('admin_notices', function() {
        echo '<div class="error"><p>' . esc_html__('Codebizz Content Privacy Pro requires PHP 7.4 or higher.', 'ccpp') . '</p></div>';
    });
    return;
}

// Include required files
$required_files = [
    'includes/class-ccpp-core.php',
    'includes/class-ccpp-admin.php',
    'includes/class-ccpp-frontend.php',
    'includes/class-ccpp-membership.php',
    'includes/class-ccpp-payment.php',
    'includes/class-ccpp-privacy.php',
    'includes/class-ccpp-auth.php',
];

foreach ($required_files as $file) {
    if (file_exists(CCPP_PATH . $file)) {
        require_once CCPP_PATH . $file;
    } else {
        error_log('CCPP: Missing required file: ' . $file);
        add_action('admin_notices', function() use ($file) {
            echo '<div class="error"><p>' . sprintf(esc_html__('Missing required file: %s. Please ensure all plugin files are uploaded.', 'ccpp'), esc_html($file)) . '</p></div>';
        });
    }
}

// Initialize plugin
function ccpp_init() {
    try {
        global $wpdb;
        $subscriptions_table = $wpdb->prefix . 'ccpp_subscriptions';
        $logs_table = $wpdb->prefix . 'ccpp_logs';
        $verifications_table = $wpdb->prefix . 'ccpp_email_verifications';
        if ($wpdb->get_var("SHOW TABLES LIKE '$subscriptions_table'") !== $subscriptions_table ||
            $wpdb->get_var("SHOW TABLES LIKE '$logs_table'") !== $logs_table ||
            $wpdb->get_var("SHOW TABLES LIKE '$verifications_table'") !== $verifications_table) {
            error_log('CCPP: Database tables missing. Attempting to recreate.');
            ccpp_activate();
        }

        // Initialize classes only if they exist
        if (class_exists('CCPP_Core')) {
            $ccpp_core = new CCPP_Core();
            $ccpp_core->init();
        }
        if (is_admin() && class_exists('CCPP_Admin')) {
            $ccpp_admin = new CCPP_Admin();
            $ccpp_admin->init();
        }
        if (class_exists('CCPP_Frontend')) {
            $ccpp_frontend = new CCPP_Frontend();
            $ccpp_frontend->init();
        }
        if (class_exists('CCPP_Membership')) {
            $ccpp_membership = new CCPP_Membership();
            $ccpp_membership->init();
        }
        if (class_exists('CCPP_Payment')) {
            $ccpp_payment = new CCPP_Payment();
            $ccpp_payment->init();
        }
        if (class_exists('CCPP_Privacy')) {
            $ccpp_privacy = new CCPP_Privacy();
            $ccpp_privacy->init();
        }
        if (class_exists('CCPP_Auth')) {
            $ccpp_auth = new CCPP_Auth();
            $ccpp_auth->init();
        }
    } catch (Exception $e) {
        error_log('CCPP: Initialization error: ' . $e->getMessage());
        add_action('admin_notices', function() use ($e) {
            echo '<div class="error"><p>' . esc_html__('CCPP Initialization failed: ', 'ccpp') . esc_html($e->getMessage()) . '</p></div>';
        });
    }
}
add_action('plugins_loaded', 'ccpp_init');

// Activation hook
function ccpp_activate() {
    try {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        
        // Create logs table
        $logs_table = $wpdb->prefix . 'ccpp_logs';
        $sql_logs = "CREATE TABLE $logs_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) DEFAULT 0,
            ip_address varchar(100) NOT NULL,
            attempt_type varchar(50) NOT NULL,
            attempt_time datetime NOT NULL,
            PRIMARY KEY (id)
        ) $charset_collate;";
        
        // Create subscriptions table
        $subscriptions_table = $wpdb->prefix . 'ccpp_subscriptions';
        $sql_subscriptions = "CREATE TABLE $subscriptions_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            plan varchar(50) NOT NULL,
            subscription_id varchar(100) NOT NULL,
            status varchar(50) NOT NULL,
            created_at datetime NOT NULL,
            expires_at datetime,
            PRIMARY KEY (id)
        ) $charset_collate;";
        
        // Create email verifications table
        $verifications_table = $wpdb->prefix . 'ccpp_email_verifications';
        $sql_verifications = "CREATE TABLE $verifications_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            token varchar(100) NOT NULL,
            created_at datetime NOT NULL,
            expires_at datetime NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY token (token)
        ) $charset_collate;";
        
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql_logs);
        dbDelta($sql_subscriptions);
        dbDelta($sql_verifications);

        // Define pages to create
        $pages = [
            'login' => ['title' => 'Login', 'content' => '[ccpp_login]', 'option' => 'ccpp_page_login'],
            'register' => ['title' => 'Register', 'content' => '[ccpp_register]', 'option' => 'ccpp_page_register'],
            'account' => ['title' => 'Account', 'content' => '[ccpp_account]', 'option' => 'ccpp_page_account'],
            'user-profile' => ['title' => 'User Profile', 'content' => '[ccpp_user_profile]', 'option' => 'ccpp_page_user_profile'],
            'password-reset' => ['title' => 'Password Reset', 'content' => '[ccpp_password_reset]', 'option' => 'ccpp_page_password_reset'],
            'logout' => ['title' => 'Logout', 'content' => '[ccpp_logout]', 'option' => 'ccpp_page_logout'],
            'member-directory' => ['title' => 'Member Directory', 'content' => '[ccpp_member_directory]', 'option' => 'ccpp_page_member_directory'],
            'pricing' => ['title' => 'Pricing', 'content' => '[ccpp_pricing]', 'option' => 'ccpp_page_pricing'],
        ];

        // Create pages and store IDs
        foreach ($pages as $slug => $page) {
            $existing_page = get_page_by_path($slug);
            if (!$existing_page) {
                $page_id = wp_insert_post([
                    'post_title' => $page['title'],
                    'post_content' => $page['content'],
                    'post_status' => 'publish',
                    'post_type' => 'page',
                    'post_name' => $slug,
                ]);
                if (!is_wp_error($page_id)) {
                    update_option($page['option'], $page_id);
                } else {
                    error_log('CCPP: Failed to create page ' . $page['title'] . ': ' . $page_id->get_error_message());
                }
            } else {
                update_option($page['option'], $existing_page->ID);
            }
        }

        // Set default options
        update_option('ccpp_right_click', '1');
        update_option('ccpp_keyboard_shortcuts', '1');
        update_option('ccpp_selection_block', '1');
        update_option('ccpp_copy_alert', '1');
        update_option('ccpp_protection_enabled', '1');
        update_option('ccpp_watermark_enabled', '1');
        update_option('ccpp_registration_enabled', '1');
        update_option('ccpp_email_verification', '1');
        update_option('ccpp_member_directory_enabled', '1');

        // Create or update navigation menu
        ccpp_setup_navigation_menu();
    } catch (Exception $e) {
        error_log('CCPP: Activation error: ' . $e->getMessage());
    }
}
register_activation_hook(__FILE__, 'ccpp_activate');

// Function to setup navigation menu
function ccpp_setup_navigation_menu() {
    try {
        $menu_name = 'CCPP Navigation';
        $menu_id = get_option('ccpp_nav_menu_id', 0);

        // Check if menu exists
        if (!$menu_id || !wp_get_nav_menu_object($menu_id)) {
            $menu_id = wp_create_nav_menu($menu_name);
            if (is_wp_error($menu_id)) {
                error_log('CCPP: Failed to create navigation menu: ' . $menu_id->get_error_message());
                return;
            }
            update_option('ccpp_nav_menu_id', $menu_id);
        }

        // Define menu items
        $pages = [
            'login' => ['title' => 'Login', 'option' => 'ccpp_page_login'],
            'register' => ['title' => 'Register', 'option' => 'ccpp_page_register'],
            'account' => ['title' => 'Account', 'option' => 'ccpp_page_account'],
            'user-profile' => ['title' => 'User Profile', 'option' => 'ccpp_page_user_profile'],
            'logout' => ['title' => 'Logout', 'option' => 'ccpp_page_logout'],
            'member-directory' => ['title' => 'Member Directory', 'option' => 'ccpp_page_member_directory'],
        ];

        // Add menu items
        foreach ($pages as $slug => $page) {
            $page_id = get_option($page['option']);
            if ($page_id) {
                // Check if menu item already exists
                $existing_items = wp_get_nav_menu_items($menu_id);
                $item_exists = false;
                foreach ($existing_items as $item) {
                    if ($item->object_id == $page_id && $item->object == 'page') {
                        $item_exists = true;
                        break;
                    }
                }

                if (!$item_exists) {
                    wp_update_nav_menu_item($menu_id, 0, [
                        'menu-item-title' => $page['title'],
                        'menu-item-object-id' => $page_id,
                        'menu-item-object' => 'page',
                        'menu-item-type' => 'post_type',
                        'menu-item-status' => 'publish',
                    ]);
                }
            }
        }
    } catch (Exception $e) {
        error_log('CCPP: Navigation menu setup error: ' . $e->getMessage());
    }
}

// Enqueue assets
function ccpp_enqueue_assets() {
    try {
        $is_admin_dashboard = is_admin() && current_user_can('manage_options');
        
        if (is_admin()) {
            wp_enqueue_style('ccpp-admin-style', CCPP_URL . 'assets/css/admin.css', [], CCPP_VERSION);
            wp_enqueue_script('ccpp-admin-script', CCPP_URL . 'assets/js/admin.js', ['jquery'], CCPP_VERSION, true);
            wp_localize_script('ccpp-admin-script', 'ccpp_admin', [
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('ccpp_admin_nonce'),
            ]);
        }

        wp_enqueue_style('ccpp-frontend-style', CCPP_URL . 'assets/css/frontend.css', [], CCPP_VERSION);
        wp_enqueue_script('ccpp-frontend-script', CCPP_URL . 'assets/js/frontend.js', ['jquery'], CCPP_VERSION, true);
        wp_localize_script('ccpp-frontend-script', 'ccpp_frontend', [
            'copy_alert' => esc_js(__('Copying is not allowed.', 'ccpp')),
            'screenshot_alert' => esc_js(__('Content is protected.', 'ccpp')),
            'is_premium' => ccpp_is_premium_user() ? '1' : '0',
            'protection_enabled' => get_option('ccpp_protection_enabled', '1'),
            'image_protection' => get_option('ccpp_image_protection', '0'),
            'right_click' => get_option('ccpp_right_click', '1'),
            'keyboard_shortcuts' => get_option('ccpp_keyboard_shortcuts', '1'),
            'selection_block' => get_option('ccpp_selection_block', '1'),
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ccpp_frontend_nonce'),
            'is_admin_dashboard' => $is_admin_dashboard ? '1' : '0',
            'login_url' => get_permalink(get_option('ccpp_page_login')) ?: home_url('/login'),
            'register_url' => get_permalink(get_option('ccpp_page_register')) ?: home_url('/register'),
            'account_url' => get_permalink(get_option('ccpp_page_account')) ?: home_url('/account'),
            'profile_url' => get_permalink(get_option('ccpp_page_user_profile')) ?: home_url('/user-profile'),
            'password_reset_url' => get_permalink(get_option('ccpp_page_password_reset')) ?: home_url('/password-reset'),
            'logout_url' => get_permalink(get_option('ccpp_page_logout')) ?: home_url('/logout'),
            'pricing_url' => get_permalink(get_option('ccpp_page_pricing')) ?: home_url('/pricing'),
        ]);
    } catch (Exception $e) {
        error_log('CCPP: Enqueue assets error: ' . $e->getMessage());
    }
}
add_action('wp_enqueue_scripts', 'ccpp_enqueue_assets');
add_action('admin_enqueue_scripts', 'ccpp_enqueue_assets');

// Check if user has premium access
function ccpp_is_premium_user() {
    return get_option('ccpp_license_valid', false);
}

// Get user plan
function ccpp_get_user_plan($user_id = null) {
    try {
        if (!$user_id && !is_user_logged_in()) {
            return false;
        }
        $user_id = $user_id ?: get_current_user_id();
        global $wpdb;
        $table = $wpdb->prefix . 'ccpp_subscriptions';
        $plan = $wpdb->get_var($wpdb->prepare(
            "SELECT plan FROM $table WHERE user_id = %d AND status = 'active' AND expires_at > %s LIMIT 1",
            $user_id,
            current_time('mysql')
        ));
        return $plan ?: 'free';
    } catch (Exception $e) {
        error_log('CCPP: Get user plan error: ' . $e->getMessage());
        return false;
    }
}

// Add admin menu
function ccpp_admin_menu() {
    try {
        add_menu_page(
            __('CCPP Dashboard', 'ccpp'),
            __('CCPP', 'ccpp'),
            'manage_options',
            'ccpp-dashboard',
            ['CCPP_Admin', 'dashboard_page'],
            'dashicons-shield',
            6
        );
        add_submenu_page(
            'ccpp-dashboard',
            __('Settings', 'ccpp'),
            __('Settings', 'ccpp'),
            'manage_options',
            'ccpp-settings',
            ['CCPP_Admin', 'settings_page']
        );
        add_submenu_page(
            'ccpp-dashboard',
            __('Membership', 'ccpp'),
            __('Membership', 'ccpp'),
            'manage_options',
            'ccpp-membership',
            ['CCPP_Admin', 'membership_page']
        );
        add_submenu_page(
            'ccpp-dashboard',
            __('User History', 'ccpp'),
            __('User History', 'ccpp'),
            'manage_options',
            'ccpp-user-history',
            ['CCPP_Admin', 'user_history_page']
        );
    } catch (Exception $e) {
        error_log('CCPP: Admin menu error: ' . $e->getMessage());
    }
}
add_action('admin_menu', 'ccpp_admin_menu');

// AJAX handler for toggling protection
function ccpp_toggle_protection() {
    try {
        check_ajax_referer('ccpp_admin_nonce', 'nonce');
        $current_status = get_option('ccpp_protection_enabled', '1');
        $new_status = $current_status === '1' ? '0' : '1';
        update_option('ccpp_protection_enabled', $new_status);
        wp_send_json_success(['status' => $new_status, 'message' => $new_status === '1' ? 'Enabled' : 'Disabled']);
    } catch (Exception $e) {
        error_log('CCPP: Toggle protection error: ' . $e->getMessage());
        wp_send_json_error(['message' => __('Failed to toggle protection.', 'ccpp')]);
    }
}
add_action('wp_ajax_ccpp_toggle_protection', 'ccpp_toggle_protection');

// AJAX handlers for user actions
function ccpp_approve_user() {
    try {
        check_admin_referer('ccpp_approve_user');
        $user_id = intval($_GET['user_id'] ?? 0);
        if ($user_id) {
            update_user_meta($user_id, 'ccpp_status', 'approved');
            wp_redirect(admin_url('admin.php?page=ccpp-user-history&message=approved'));
            exit;
        }
        wp_die(__('Invalid user ID.', 'ccpp'));
    } catch (Exception $e) {
        error_log('CCPP: Approve user error: ' . $e->getMessage());
        wp_die(__('Failed to approve user.', 'ccpp'));
    }
}
add_action('wp_ajax_ccpp_approve_user', 'ccpp_approve_user');

function ccpp_reject_user() {
    try {
        check_admin_referer('ccpp_reject_user');
        $user_id = intval($_GET['user_id'] ?? 0);
        if ($user_id) {
            update_user_meta($user_id, 'ccpp_status', 'rejected');
            wp_redirect(admin_url('admin.php?page=ccpp-user-history&message=rejected'));
            exit;
        }
        wp_die(__('Invalid user ID.', 'ccpp'));
    } catch (Exception $e) {
        error_log('CCPP: Reject user error: ' . $e->getMessage());
        wp_die(__('Failed to reject user.', 'ccpp'));
    }
}
add_action('wp_ajax_ccpp_reject_user', 'ccpp_reject_user');

function ccpp_delete_user() {
    try {
        check_admin_referer('ccpp_delete_user');
        $user_id = intval($_GET['user_id'] ?? 0);
        if ($user_id && !current_user_can('administrator', $user_id)) {
            wp_delete_user($user_id);
            global $wpdb;
            $wpdb->delete($wpdb->prefix . 'ccpp_subscriptions', ['user_id' => $user_id], ['%d']);
            $wpdb->delete($wpdb->prefix . 'ccpp_email_verifications', ['user_id' => $user_id], ['%d']);
            wp_redirect(admin_url('admin.php?page=ccpp-user-history&message=deleted'));
            exit;
        }
        wp_die(__('Invalid user ID or cannot delete admin.', 'ccpp'));
    } catch (Exception $e) {
        error_log('CCPP: Delete user error: ' . $e->getMessage());
        wp_die(__('Failed to delete user.', 'ccpp'));
    }
}
add_action('wp_ajax_ccpp_delete_user', 'ccpp_delete_user');

// Ensure page creation is allowed for authorized users
function ccpp_allow_page_creation() {
    try {
        global $pagenow;
        if ($pagenow === 'post-new.php' && isset($_GET['post_type']) && $_GET['post_type'] === 'page') {
            if (!current_user_can('edit_pages')) {
                error_log('CCPP: Access denied to post-new.php for user ID ' . get_current_user_id() . '. Capabilities: ' . print_r(get_userdata(get_current_user_id())->allcaps, true));
                // Allow debugging without redirecting
            }
        }
    } catch (Exception $e) {
        error_log('CCPP: Page creation check error: ' . $e->getMessage());
    }
}
add_action('admin_init', 'ccpp_allow_page_creation', 1);
?>