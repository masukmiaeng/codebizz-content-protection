<?php
if (!defined('ABSPATH')) {
    exit;
}

class CCPP_Admin {
    public function init() {
        try {
            add_action('admin_init', [$this, 'register_settings'], 10);
            // Add check to ensure page creation is not blocked
            add_action('admin_init', [$this, 'check_page_creation_access'], 1);
        } catch (Exception $e) {
            error_log('CCPP: Admin init error: ' . $e->getMessage());
        }
    }

    public function check_page_creation_access() {
        try {
            global $pagenow;
            if ($pagenow === 'post-new.php' && isset($_GET['post_type']) && $_GET['post_type'] === 'page') {
                if (!current_user_can('edit_pages')) {
                    error_log('CCPP: User ID ' . get_current_user_id() . ' lacks edit_pages capability for page creation.');
                }
            }
        } catch (Exception $e) {
            error_log('CCPP: Page creation access check error: ' . $e->getMessage());
        }
    }

    public function register_settings() {
        try {
            register_setting('ccpp_settings_group', 'ccpp_protection_enabled');
            register_setting('ccpp_settings_group', 'ccpp_right_click');
            register_setting('ccpp_settings_group', 'ccpp_keyboard_shortcuts');
            register_setting('ccpp_settings_group', 'ccpp_selection_block');
            register_setting('ccpp_settings_group', 'ccpp_copy_alert');
            register_setting('ccpp_settings_group', 'ccpp_image_protection');
            register_setting('ccpp_settings_group', 'ccpp_watermark_enabled');
            register_setting('ccpp_settings_group', 'ccpp_privacy_enabled');
            register_setting('ccpp_settings_group', 'ccpp_paypal_mode');
            register_setting('ccpp_settings_group', 'ccpp_paypal_client_id');
            register_setting('ccpp_settings_group', 'ccpp_paypal_client_secret');
            register_setting('ccpp_settings_group', 'ccpp_registration_enabled');
            register_setting('ccpp_settings_group', 'ccpp_email_verification');
            register_setting('ccpp_settings_group', 'ccpp_member_directory_enabled');
            register_setting('ccpp_settings_group', 'ccpp_nav_menu_id');
        } catch (Exception $e) {
            error_log('CCPP: Register settings error: ' . $e->getMessage());
        }
    }

    public static function dashboard_page() {
        try {
            ?>
            <div class="ccpp-wrap">
                <h1><?php _e('Codebizz Content Privacy Pro', 'ccpp'); ?></h1>
                <div class="ccpp-dashboard">
                    <div class="ccpp-widget neumorphic">
                        <h2><?php _e('Protection Status', 'ccpp'); ?></h2>
                        <p><?php echo get_option('ccpp_protection_enabled', '1') ? __('Enabled', 'ccpp') : __('Disabled', 'ccpp'); ?></p>
                        <button class="ccpp-toggle-protection button button-primary"><?php _e('Toggle Protection', 'ccpp'); ?></button>
                    </div>
                    <div class="ccpp-widget neumorphic">
                        <h2><?php _e('License Status', 'ccpp'); ?></h2>
                        <p><?php echo ccpp_is_premium_user() ? __('Premium Active', 'ccpp') : __('Free Version', 'ccpp'); ?></p>
                        <?php if (!ccpp_is_premium_user()) : ?>
                            <a href="https://codebizz.net/purchase" class="button button-primary"><?php _e('Upgrade to Premium', 'ccpp'); ?></a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php
        } catch (Exception $e) {
            error_log('CCPP: Dashboard page error: ' . $e->getMessage());
            echo '<div class="error"><p>' . esc_html__('Failed to load dashboard.', 'ccpp') . '</p></div>';
        }
    }

    public static function settings_page() {
        try {
            if (isset($_POST['ccpp_save_settings']) && check_admin_referer('ccpp_save_settings')) {
                update_option('ccpp_right_click', isset($_POST['ccpp_right_click']) ? '1' : '0');
                update_option('ccpp_keyboard_shortcuts', isset($_POST['ccpp_keyboard_shortcuts']) ? '1' : '0');
                update_option('ccpp_selection_block', isset($_POST['ccpp_selection_block']) ? '1' : '0');
                update_option('ccpp_copy_alert', isset($_POST['ccpp_copy_alert']) ? '1' : '0');
                update_option('ccpp_image_protection', isset($_POST['ccpp_image_protection']) ? '1' : '0');
                update_option('ccpp_privacy_enabled', isset($_POST['ccpp_privacy_enabled']) ? '1' : '0');
                update_option('ccpp_watermark_enabled', isset($_POST['ccpp_watermark_enabled']) ? '1' : '0');
                update_option('ccpp_paypal_mode', sanitize_text_field($_POST['ccpp_paypal_mode'] ?? 'sandbox'));
                update_option('ccpp_paypal_client_id', sanitize_text_field($_POST['ccpp_paypal_client_id'] ?? ''));
                update_option('ccpp_paypal_client_secret', sanitize_text_field($_POST['ccpp_paypal_client_secret'] ?? ''));
                update_option('ccpp_registration_enabled', isset($_POST['ccpp_registration_enabled']) ? '1' : '0');
                update_option('ccpp_email_verification', isset($_POST['ccpp_email_verification']) ? '1' : '0');
                update_option('ccpp_member_directory_enabled', isset($_POST['ccpp_member_directory_enabled']) ? '1' : '0');
                update_option('ccpp_nav_menu_id', intval($_POST['ccpp_nav_menu_id'] ?? 0));

                // Recreate pages if requested
                if (isset($_POST['ccpp_recreate_pages'])) {
                    self::recreate_pages();
                }

                // Update navigation menu
                ccpp_setup_navigation_menu();

                echo '<div class="notice notice-success"><p>' . esc_html__('Settings saved.', 'ccpp') . '</p></div>';
            }

            // Get available menus
            $menus = wp_get_nav_menus();
            $selected_menu_id = get_option('ccpp_nav_menu_id', 0);
            ?>
            <div class="ccpp-wrap">
                <h1><?php _e('CCPP Settings', 'ccpp'); ?></h1>
                <form method="post" action="">
                    <?php wp_nonce_field('ccpp_save_settings'); ?>
                    <h2><?php _e('Protection Settings', 'ccpp'); ?></h2>
                    <table class="form-table">
                        <tr>
                            <th><?php _e('Disable Right Click', 'ccpp'); ?></th>
                            <td><input type="checkbox" name="ccpp_right_click" <?php checked(get_option('ccpp_right_click', '1'), '1'); ?>></td>
                        </tr>
                        <tr>
                            <th><?php _e('Disable Keyboard Shortcuts', 'ccpp'); ?></th>
                            <td><input type="checkbox" name="ccpp_keyboard_shortcuts" <?php checked(get_option('ccpp_keyboard_shortcuts', '1'), '1'); ?>></td>
                        </tr>
                        <tr>
                            <th><?php _e('Block Selection', 'ccpp'); ?></th>
                            <td><input type="checkbox" name="ccpp_selection_block" <?php checked(get_option('ccpp_selection_block', '1'), '1'); ?>></td>
                        </tr>
                        <tr>
                            <th><?php _e('Copy Alert Popup', 'ccpp'); ?></th>
                            <td><input type="checkbox" name="ccpp_copy_alert" <?php checked(get_option('ccpp_copy_alert', '1'), '1'); ?>></td>
                        </tr>
                        <tr>
                            <th><?php _e('Image Protection', 'ccpp'); ?></th>
                            <td>
                                <input type="checkbox" name="ccpp_image_protection" <?php checked(get_option('ccpp_image_protection', '0')); ?> <?php echo !ccpp_is_premium_user() ? 'disabled' : ''; ?>>
                                <?php if (!ccpp_is_premium_user()) : ?>
                                    <span><?php _e('Premium Feature', 'ccpp'); ?></span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th><?php _e('Watermark Protection', 'ccpp'); ?></th>
                            <td><input type="checkbox" name="ccpp_watermark_enabled" <?php checked(get_option('ccpp_watermark_enabled', '1'), '1'); ?>></td>
                        </tr>
                        <tr>
                            <th><?php _e('GDPR Privacy', 'ccpp'); ?></th>
                            <td><input type="checkbox" name="ccpp_privacy_enabled" <?php checked(get_option('ccpp_privacy_enabled', '0')); ?>></td>
                        </tr>
                    </table>

                    <h2><?php _e('Authentication Settings', 'ccpp'); ?></h2>
                    <table class="form-table">
                        <tr>
                            <th><?php _e('Enable Registration', 'ccpp'); ?></th>
                            <td><input type="checkbox" name="ccpp_registration_enabled" <?php checked(get_option('ccpp_registration_enabled', '1'), '1'); ?>></td>
                        </tr>
                        <tr>
                            <th><?php _e('Enable Email Verification', 'ccpp'); ?></th>
                            <td><input type="checkbox" name="ccpp_email_verification" <?php checked(get_option('ccpp_email_verification', '1'), '1'); ?>></td>
                        </tr>
                        <tr>
                            <th><?php _e('Enable Member Directory', 'ccpp'); ?></th>
                            <td><input type="checkbox" name="ccpp_member_directory_enabled" <?php checked(get_option('ccpp_member_directory_enabled', '1'), '1'); ?>></td>
                        </tr>
                    </table>

                    <h2><?php _e('Navigation Menu Settings', 'ccpp'); ?></h2>
                    <table class="form-table">
                        <tr>
                            <th><?php _e('Select Navigation Menu', 'ccpp'); ?></th>
                            <td>
                                <select name="ccpp_nav_menu_id">
                                    <option value="0"><?php _e('Create New Menu (CCPP Navigation)', 'ccpp'); ?></option>
                                    <?php foreach ($menus as $menu) : ?>
                                        <option value="<?php echo esc_attr($menu->term_id); ?>" <?php selected($selected_menu_id, $menu->term_id); ?>>
                                            <?php echo esc_html($menu->name); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <p class="description"><?php _e('Select an existing menu or choose to create a new one for CCPP pages.', 'ccpp'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th><?php _e('Recreate Pages', 'ccpp'); ?></th>
                            <td>
                                <input type="checkbox" name="ccpp_recreate_pages">
                                <p class="description"><?php _e('Check to recreate all CCPP pages (Login, Register, etc.). Existing pages will be updated.', 'ccpp'); ?></p>
                            </td>
                        </tr>
                    </table>

                    <h2><?php _e('PayPal Settings', 'ccpp'); ?></h2>
                    <table class="form-table">
                        <tr>
                            <th><?php _e('PayPal Mode', 'ccpp'); ?></th>
                            <td>
                                <select name="ccpp_paypal_mode">
                                    <option value="sandbox" <?php selected(get_option('ccpp_paypal_mode', 'sandbox'), 'sandbox'); ?>><?php _e('Sandbox', 'ccpp'); ?></option>
                                    <option value="live" <?php selected(get_option('ccpp_paypal_mode'), 'live'); ?>><?php _e('Live', 'ccpp'); ?></option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th><?php _e('PayPal Client ID', 'ccpp'); ?></th>
                            <td><input type="text" name="ccpp_paypal_client_id" value="<?php echo esc_attr(get_option('ccpp_paypal_client_id', '')); ?>" class="regular-text"></td>
                        </tr>
                        <tr>
                            <th><?php _e('PayPal Client Secret', 'ccpp'); ?></th>
                            <td><input type="text" name="ccpp_paypal_client_secret" value="<?php echo esc_attr(get_option('ccpp_paypal_client_secret', '')); ?>" class="regular-text"></td>
                        </tr>
                    </table>

                    <p class="submit"><input type="submit" name="ccpp_save_settings" class="button button-primary" value="<?php _e('Save Settings', 'ccpp'); ?>"></p>
                </form>
            </div>
            <?php
        } catch (Exception $e) {
            error_log('CCPP: Settings page error: ' . $e->getMessage());
            echo '<div class="error"><p>' . esc_html__('Failed to load settings page.', 'ccpp') . '</p></div>';
        }
    }

    public static function recreate_pages() {
        try {
            $pages = [
                'login' => ['title' => 'Login', 'content' => '[ccpp_login]', 'option' => 'ccpp_page_login'],
                'register' => ['title' => 'Register', 'content' => '[ccpp_register]', 'option' => 'ccpp_page_register'],
                'account' => ['title' => 'Account', 'content' => '[ccpp_account]', 'option' => 'ccpp_page_account'],
                'user-profile' => ['title' => 'User Profile', 'content' => '[ccpp_user_profile]', 'option' => 'ccpp_page_user_profile'],
                'password-reset' => ['title' => 'Password Reset', 'content' => '[ccpp_password_reset]', 'option' => 'ccpp_page_password_reset'],
                'logout' => ['title' => 'Logout', 'content' => '[ccpp_logout]', 'option' => 'ccpp_page_logout'],
                'member-directory' => ['title' => 'Member Directory', 'content' => '[ccpp_member_directory]', 'option' => 'ccpp_page_member_directory'],
                'pricing' => ['title' => 'Pricing', 'content' => '[ccpp_pricing]', 'option' => 'ccpp_page_pricing'],
            ];

            foreach ($pages as $slug => $page) {
                $existing_page = get_page_by_path($slug);
                if ($existing_page) {
                    wp_update_post([
                        'ID' => $existing_page->ID,
                        'post_content' => $page['content'],
                        'post_status' => 'publish',
                    ]);
                    update_option($page['option'], $existing_page->ID);
                } else {
                    $page_id = wp_insert_post([
                        'post_title' => $page['title'],
                        'post_content' => $page['content'],
                        'post_status' => 'publish',
                        'post_type' => 'page',
                        'post_name' => $slug,
                    ]);
                    if (!is_wp_error($page_id)) {
                        update_option($page['option'], $page_id);
                    } else {
                        error_log('CCPP: Failed to recreate page ' . $page['title'] . ': ' . $page_id->get_error_message());
                    }
                }
            }
        } catch (Exception $e) {
            error_log('CCPP: Recreate pages error: ' . $e->getMessage());
        }
    }

    public static function membership_page() {
        try {
            global $wpdb;
            $table = $wpdb->prefix . 'ccpp_subscriptions';
            $subscriptions = $wpdb->get_results("SELECT * FROM $table ORDER BY created_at DESC");
            ?>
            <div class="ccpp-wrap">
                <h1><?php _e('Membership Management', 'ccpp'); ?></h1>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th><?php _e('User ID', 'ccpp'); ?></th>
                            <th><?php _e('Plan', 'ccpp'); ?></th>
                            <th><?php _e('Order ID', 'ccpp'); ?></th>
                            <th><?php _e('Status', 'ccpp'); ?></th>
                            <th><?php _e('Created At', 'ccpp'); ?></th>
                            <th><?php _e('Expires At', 'ccpp'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($subscriptions) : ?>
                            <?php foreach ($subscriptions as $sub) : ?>
                                <tr>
                                    <td><?php echo esc_html($sub->user_id); ?></td>
                                    <td><?php echo esc_html(ucfirst($sub->plan)); ?></td>
                                    <td><?php echo esc_html($sub->subscription_id); ?></td>
                                    <td><?php echo esc_html($sub->status); ?></td>
                                    <td><?php echo esc_html($sub->created_at); ?></td>
                                    <td><?php echo esc_html($sub->expires_at ?: '-'); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else : ?>
                            <tr>
                                <td colspan="6"><?php _e('No subscriptions found.', 'ccpp'); ?></td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <?php
        } catch (Exception $e) {
            error_log('CCPP: Membership page error: ' . $e->getMessage());
            echo '<div class="error"><p>' . esc_html__('Failed to load membership page.', 'ccpp') . '</p></div>';
        }
    }

    public static function user_history_page() {
        try {
            global $wpdb;
            $users = get_users(['meta_key' => 'ccpp_status']);
            $logs_table = $wpdb->prefix . 'ccpp_logs';
            ?>
            <div class="ccpp-wrap">
                <h1><?php _e('User History', 'ccpp'); ?></h1>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th><?php _e('User ID', 'ccpp'); ?></th>
                            <th><?php _e('Username', 'ccpp'); ?></th>
                            <th><?php _e('Email', 'ccpp'); ?></th>
                            <th><?php _e('Status', 'ccpp'); ?></th>
                            <th><?php _e('Last Login', 'ccpp'); ?></th>
                            <th><?php _e('Registration Date', 'ccpp'); ?></th>
                            <th><?php _e('Plan', 'ccpp'); ?></th>
                            <th><?php _e('Actions', 'ccpp'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($users) : ?>
                            <?php foreach ($users as $user) : ?>
                                <?php
                                $status = get_user_meta($user->ID, 'ccpp_status', true) ?: 'pending';
                                $last_login = $wpdb->get_var($wpdb->prepare(
                                    "SELECT attempt_time FROM $logs_table WHERE user_id = %d AND attempt_type = 'successful_login' ORDER BY attempt_time DESC LIMIT 1",
                                    $user->ID
                                ));
                                $plan = ccpp_get_user_plan($user->ID) ?: 'free';
                                ?>
                                <tr>
                                    <td><?php echo esc_html($user->ID); ?></td>
                                    <td><?php echo esc_html($user->user_login); ?></td>
                                    <td><?php echo esc_html($user->user_email); ?></td>
                                    <td><?php echo esc_html(ucfirst($status)); ?></td>
                                    <td><?php echo esc_html($last_login ?: '-'); ?></td>
                                    <td><?php echo esc_html($user->user_registered); ?></td>
                                    <td><?php echo esc_html(ucfirst($plan)); ?></td>
                                    <td>
                                        <?php if ($status !== 'approved') : ?>
                                            <a href="<?php echo wp_nonce_url(admin_url('admin-ajax.php?action=ccpp_approve_user&user_id=' . $user->ID), 'ccpp_approve_user'); ?>" class="button"><?php _e('Approve', 'ccpp'); ?></a>
                                        <?php endif; ?>
                                        <?php if ($status !== 'rejected') : ?>
                                            <a href="<?php echo wp_nonce_url(admin_url('admin-ajax.php?action=ccpp_reject_user&user_id=' . $user->ID), 'ccpp_reject_user'); ?>" class="button"><?php _e('Reject', 'ccpp'); ?></a>
                                        <?php endif; ?>
                                        <a href="<?php echo wp_nonce_url(admin_url('admin-ajax.php?action=ccpp_delete_user&user_id=' . $user->ID), 'ccpp_delete_user'); ?>" class="button" onclick="return confirm('<?php _e('Are you sure you want to delete this user?', 'ccpp'); ?>');"><?php _e('Delete', 'ccpp'); ?></a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else : ?>
                            <tr>
                                <td colspan="8"><?php _e('No users found.', 'ccpp'); ?></td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <?php
        } catch (Exception $e) {
            error_log('CCPP: User history page error: ' . $e->getMessage());
            echo '<div class="error"><p>' . esc_html__('Failed to load user history page.', 'ccpp') . '</p></div>';
        }
    }
}
?>