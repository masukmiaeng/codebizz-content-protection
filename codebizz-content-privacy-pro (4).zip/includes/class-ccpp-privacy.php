<?php
if (!defined('ABSPATH')) {
    exit;
}

class CCPP_Privacy {
    public function init() {
        try {
            add_action('add_meta_boxes', [$this, 'add_privacy_meta_box']);
            add_action('save_post', [$this, 'save_privacy_meta']);
            add_action('wp_ajax_ccpp_verify_password', [$this, 'ajax_verify_password']);
            add_action('wp_ajax_nopriv_ccpp_verify_password', [$this, 'ajax_verify_password']);
        } catch (Exception $e) {
            error_log('CCPP: Privacy init error: ' . $e->getMessage());
        }
    }

    public function add_privacy_meta_box() {
        try {
            add_meta_box(
                'ccpp_privacy_settings',
                __('Content Privacy Settings', 'ccpp'),
                [$this, 'render_privacy_meta_box'],
                'post',
                'side',
                'high'
            );
        } catch (Exception $e) {
            error_log('CCPP: Add privacy meta box error: ' . $e->getMessage());
        }
    }

    public function render_privacy_meta_box($post) {
        try {
            wp_nonce_field('ccpp_privacy_nonce', 'ccpp_privacy_nonce');

            $access_level = get_post_meta($post->ID, 'ccpp_access_level', true);
            $protect_by_password = get_post_meta($post->ID, 'ccpp_protect_by_password', true);
            $content_password = get_post_meta($post->ID, 'ccpp_content_password', true);
            $post_payment_enabled = get_post_meta($post->ID, 'ccpp_post_payment_enabled', true);
            $post_payment_amount = get_post_meta($post->ID, 'ccpp_post_payment_amount', true);
            $require_lifetime_plan = get_post_meta($post->ID, 'ccpp_require_lifetime_plan', true);
            $lifetime_plan_level = get_post_meta($post->ID, 'ccpp_lifetime_plan_level', true);

            ?>
            <p>
                <label class="block text-sm font-medium text-gray-700"><?php _e('Access Level', 'ccpp'); ?></label>
                <select name="ccpp_access_level" class="w-full p-2 border rounded-lg">
                    <option value="free" <?php selected($access_level, 'free'); ?>><?php _e('Free', 'ccpp'); ?></option>
                    <option value="silver" <?php selected($access_level, 'silver'); ?>><?php _e('Silver', 'ccpp'); ?></option>
                    <option value="premium" <?php selected($access_level, 'premium'); ?>><?php _e('Premium', 'ccpp'); ?></option>
                    <option value="platinum" <?php selected($access_level, 'platinum'); ?>><?php _e('Platinum', 'ccpp'); ?></option>
                </select>
            </p>
            <p>
                <label>
                    <input type="checkbox" name="ccpp_protect_by_password" value="1" <?php checked($protect_by_password, '1'); ?>>
                    <?php _e('Protect by Password', 'ccpp'); ?>
                </label>
            </p>
            <p>
                <label class="block text-sm font-medium text-gray-700"><?php _e('Content Password', 'ccpp'); ?></label>
                <input type="text" name="ccpp_content_password" value="<?php echo esc_attr($content_password); ?>" class="w-full p-2 border rounded-lg" placeholder="<?php _e('Enter password', 'ccpp'); ?>">
            </p>
            <p>
                <label>
                    <input type="checkbox" name="ccpp_post_payment_enabled" value="1" <?php checked($post_payment_enabled, '1'); ?>>
                    <?php _e('Enable One-Time Payment for This Post', 'ccpp'); ?>
                </label>
            </p>
            <p>
                <label class="block text-sm font-medium text-gray-700"><?php _e('Payment Amount ($)', 'ccpp'); ?></label>
                <input type="number" step="0.01" name="ccpp_post_payment_amount" value="<?php echo esc_attr($post_payment_amount); ?>" class="w-full p-2 border rounded-lg" placeholder="<?php _e('Enter amount (e.g., 2.00)', 'ccpp'); ?>">
            </p>
            <p>
                <label>
                    <input type="checkbox" name="ccpp_require_lifetime_plan" value="1" <?php checked($require_lifetime_plan, '1'); ?>>
                    <?php _e('Require Lifetime Plan', 'ccpp'); ?>
                </label>
            </p>
            <p>
                <label class="block text-sm font-medium text-gray-700"><?php _e('Required Lifetime Plan', 'ccpp'); ?></label>
                <select name="ccpp_lifetime_plan_level" class="w-full p-2 border rounded-lg">
                    <option value="silver" <?php selected($lifetime_plan_level, 'silver'); ?>><?php _e('Silver ($200)', 'ccpp'); ?></option>
                    <option value="premium" <?php selected($lifetime_plan_level, 'premium'); ?>><?php _e('Premium ($350)', 'ccpp'); ?></option>
                    <option value="platinum" <?php selected($lifetime_plan_level, 'platinum'); ?>><?php _e('Platinum ($500)', 'ccpp'); ?></option>
                </select>
            </p>
            <?php
        } catch (Exception $e) {
            error_log('CCPP: Render privacy meta box error: ' . $e->getMessage());
            echo '<p class="text-red-500">' . esc_html__('Failed to load privacy settings.', 'ccpp') . '</p>';
        }
    }

    public function save_privacy_meta($post_id) {
        try {
            if (!isset($_POST['ccpp_privacy_nonce']) || !wp_verify_nonce($_POST['ccpp_privacy_nonce'], 'ccpp_privacy_nonce')) {
                return;
            }

            if (!current_user_can('edit_post', $post_id)) {
                return;
            }

            $access_level = sanitize_text_field($_POST['ccpp_access_level'] ?? 'free');
            $protect_by_password = isset($_POST['ccpp_protect_by_password']) ? '1' : '0';
            $content_password = sanitize_text_field($_POST['ccpp_content_password'] ?? '');
            $post_payment_enabled = isset($_POST['ccpp_post_payment_enabled']) ? '1' : '0';
            $post_payment_amount = floatval($_POST['ccpp_post_payment_amount'] ?? 0);
            $require_lifetime_plan = isset($_POST['ccpp_require_lifetime_plan']) ? '1' : '0';
            $lifetime_plan_level = sanitize_text_field($_POST['ccpp_lifetime_plan_level'] ?? 'silver');

            update_post_meta($post_id, 'ccpp_access_level', $access_level);
            update_post_meta($post_id, 'ccpp_protect_by_password', $protect_by_password);
            update_post_meta($post_id, 'ccpp_content_password', $content_password);
            update_post_meta($post_id, 'ccpp_post_payment_enabled', $post_payment_enabled);
            update_post_meta($post_id, 'ccpp_post_payment_amount', $post_payment_amount);
            update_post_meta($post_id, 'ccpp_require_lifetime_plan', $require_lifetime_plan);
            update_post_meta($post_id, 'ccpp_lifetime_plan_level', $lifetime_plan_level);
        } catch (Exception $e) {
            error_log('CCPP: Save privacy meta error: ' . $e->getMessage());
        }
    }

    public function ajax_verify_password() {
        try {
            check_ajax_referer('ccpp_frontend_nonce', 'nonce');
            $post_id = intval($_POST['post_id'] ?? 0);
            $password = sanitize_text_field($_POST['password'] ?? '');

            if (!$post_id || !$password) {
                wp_send_json_error(['message' => __('Invalid request.', 'ccpp')]);
            }

            $stored_password = get_post_meta($post_id, 'ccpp_content_password', true);
            if ($password === $stored_password) {
                $transient_key = 'ccpp_access_' . $post_id . '_' . get_current_user_id();
                set_transient($transient_key, true, 24 * HOUR_IN_SECONDS);
                wp_send_json_success(['message' => __('Access granted.', 'ccpp')]);
            } else {
                wp_send_json_error(['message' => __('Incorrect password.', 'ccpp')]);
            }
        } catch (Exception $e) {
            error_log('CCPP: AJAX verify password error: ' . $e->getMessage());
            wp_send_json_error(['message' => __('An error occurred.', 'ccpp')]);
        }
    }
}
?>