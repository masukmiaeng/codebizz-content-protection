<?php
if (!defined('ABSPATH')) {
    exit;
}

class CCPP_Membership {
    public function init() {
        // Membership-related hooks
    }

    public function has_access($required_plan) {
        $user_plan = $this->get_user_plan();
        if (!$user_plan) {
            return false;
        }

        $plan_hierarchy = ['silver' => 1, 'premium' => 2, 'platinum' => 3];
        $user_level = $plan_hierarchy[$user_plan] ?? 0;
        $required_level = $plan_hierarchy[$required_plan] ?? 0;
        return $user_level >= $required_level;
    }

    public function get_user_plan() {
        if (!is_user_logged_in()) {
            return false;
        }
        $user_id = get_current_user_id();
        global $wpdb;
        $table = $wpdb->prefix . 'ccpp_subscriptions';
        $subscription = $wpdb->get_row($wpdb->prepare(
            "SELECT plan, expires_at FROM $table WHERE user_id = %d AND status = 'active' AND expires_at > %s LIMIT 1",
            $user_id,
            current_time('mysql')
        ));

        if (!$subscription || (isset($subscription->expires_at) && strtotime($subscription->expires_at) < time())) {
            return false;
        }

        return $subscription->plan;
    }
}
?>