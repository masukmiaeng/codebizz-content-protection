<?php
if (!defined('ABSPATH')) {
    exit;
}

class CCPP_Core {
    public function init() {
        try {
            load_plugin_textdomain('ccpp', false, dirname(CCPP_BASENAME) . '/languages');
            add_action('admin_init', [$this, 'register_settings']);
        } catch (Exception $e) {
            error_log('CCPP: Core init error: ' . $e->getMessage());
        }
    }

    public function register_settings() {
        try {
            register_setting('ccpp_settings', 'ccpp_protection_enabled');
            register_setting('ccpp_settings', 'ccpp_license_key');
        } catch (Exception $e) {
            error_log('CCPP: Core register settings error: ' . $e->getMessage());
        }
    }
}
?>