<?php
if (!defined('ABSPATH')) {
    exit;
}

class CCPP_Payment {
    private $paypal_client_id;
    private $paypal_secret;
    private $paypal_mode;
    private $paypal_api_url;

    public function init() {
        try {
            // Retrieve PayPal settings from the options table
            $this->paypal_client_id = get_option('ccpp_paypal_client_id', '');
            $this->paypal_secret = get_option('ccpp_paypal_secret', '');
            $this->paypal_mode = get_option('ccpp_paypal_mode', 'sandbox');
            $this->paypal_api_url = $this->paypal_mode === 'sandbox' ? 'https://api-m.sandbox.paypal.com' : 'https://api-m.paypal.com';

            // Debug: Log the retrieved values
            error_log('CCPP: PayPal Client ID - ' . ($this->paypal_client_id ? substr($this->paypal_client_id, 0, 5) . '...' : 'Not set'));
            error_log('CCPP: PayPal Secret - ' . ($this->paypal_secret ? 'Set (hidden for security)' : 'Not set'));
            error_log('CCPP: PayPal Mode - ' . $this->paypal_mode);

            // Add AJAX action for toggle protection
            add_action('wp_ajax_ccpp_toggle_protection', [$this, 'toggle_protection']);
            add_action('wp_ajax_nopriv_ccpp_toggle_protection', [$this, 'toggle_protection']);

            add_action('wp_ajax_ccpp_process_payment', [$this, 'process_payment']);
            add_action('wp_ajax_nopriv_ccpp_process_payment', [$this, 'process_payment']);
            add_action('wp_ajax_ccpp_process_post_payment', [$this, 'process_post_payment']);
            add_action('wp_ajax_nopriv_ccpp_process_post_payment', [$this, 'process_post_payment']);
            add_shortcode('ccpp_pricing', [$this, 'pricing_shortcode']);

            // Enqueue scripts for the frontend
            add_action('wp_enqueue_scripts', [$this, 'enqueue_scripts']);
        } catch (Exception $e) {
            error_log('CCPP: Payment init error: ' . $e->getMessage());
        }
    }

    public function enqueue_scripts() {
        // Enqueue jQuery (already included in WordPress)
        wp_enqueue_script('jquery');

        // Localize script with AJAX URL and nonce
        wp_localize_script('jquery', 'ccpp_frontend', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ccpp_frontend_nonce')
        ]);
    }

    public function toggle_protection() {
        try {
            if (!check_ajax_referer('ccpp_frontend_nonce', 'nonce', false)) {
                error_log('CCPP: Toggle protection failed - Invalid nonce.');
                wp_send_json_error(['message' => __('Security check failed. Please refresh the page and try again.', 'ccpp')]);
                return;
            }

            $enable = isset($_POST['enable']) && $_POST['enable'] === 'true' ? 1 : 0;

            // Update the protection toggle setting
            update_option('ccpp_protection_enabled', $enable);
            error_log('CCPP: Toggle protection set to ' . ($enable ? 'enabled' : 'disabled'));

            wp_send_json_success(['message' => $enable ? 'Protection enabled.' : 'Protection disabled.']);
        } catch (Exception $e) {
            error_log('CCPP: Toggle protection error: ' . $e->getMessage());
            wp_send_json_error(['message' => 'Failed to toggle protection: ' . $e->getMessage()]);
        }
    }

    private function get_access_token() {
        if (empty($this->paypal_client_id) || empty($this->paypal_secret)) {
            error_log('CCPP: Cannot get access token - PayPal Client ID or Secret is empty.');
            return false;
        }

        $credentials = base64_encode($this->paypal_client_id . ':' . $this->paypal_secret);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->paypal_api_url . '/v1/oauth2/token');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, 'grant_type=client_credentials');
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Basic ' . $credentials,
            'Content-Type: application/x-www-form-urlencoded'
        ]);

        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curl_error = curl_error($ch);
        curl_close($ch);

        if ($response === false) {
            error_log('CCPP: Failed to get PayPal access token: cURL error - ' . $curl_error);
            return false;
        }

        if ($http_code !== 200) {
            error_log('CCPP: Failed to get PayPal access token: HTTP ' . $http_code . ' - Response: ' . $response);
            return false;
        }

        $data = json_decode($response, true);
        if (isset($data['error'])) {
            error_log('CCPP: PayPal API error - ' . $data['error_description']);
            return false;
        }

        $token = $data['access_token'] ?? false;
        if (!$token) {
            error_log('CCPP: Failed to get PayPal access token: No access token in response - ' . $response);
        }
        return $token;
    }

    private function create_paypal_order($amount) {
        $token = $this->get_access_token();
        if (!$token) {
            error_log('CCPP: Cannot create PayPal order - No access token.');
            return false;
        }

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->paypal_api_url . '/v2/checkout/orders');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
            'intent' => 'CAPTURE',
            'purchase_units' => [[
                'amount' => [
                    'currency_code' => 'USD',
                    'value' => number_format($amount, 2, '.', '')
                ]
            ]]
        ]));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $token,
            'Content-Type: application/json'
        ]);

        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curl_error = curl_error($ch);
        curl_close($ch);

        if ($response === false) {
            error_log('CCPP: Failed to create PayPal order: cURL error - ' . $curl_error);
            return false;
        }

        if ($http_code !== 201) {
            error_log('CCPP: Failed to create PayPal order: HTTP ' . $http_code . ' - Response: ' . $response);
            return false;
        }

        $data = json_decode($response, true);
        $approval_url = $data['links'][0]['href'] ?? false;
        if (!$approval_url) {
            error_log('CCPP: Failed to create PayPal order: No approval URL in response - ' . $response);
        }
        return $approval_url;
    }

    private function create_paypal_subscription($plan_id) {
        $token = $this->get_access_token();
        if (!$token) {
            error_log('CCPP: Cannot create PayPal subscription - No access token.');
            return false;
        }

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->paypal_api_url . '/v1/billing/subscriptions');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
            'plan_id' => $plan_id,
            'start_time' => date('c', strtotime('+1 minute')),
            'subscriber' => ['name' => ['given_name' => 'Subscriber']],
            'application_context' => [
                'brand_name' => 'CCPP',
                'locale' => 'en-US',
                'return_url' => home_url(),
                'cancel_url' => home_url()
            ]
        ]));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $token,
            'Content-Type: application/json'
        ]);

        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curl_error = curl_error($ch);
        curl_close($ch);

        if ($response === false) {
            error_log('CCPP: Failed to create PayPal subscription: cURL error - ' . $curl_error);
            return false;
        }

        if ($http_code !== 201) {
            error_log('CCPP: Failed to create PayPal subscription: HTTP ' . $http_code . ' - Response: ' . $response);
            return false;
        }

        $data = json_decode($response, true);
        $approval_url = $data['links'][0]['href'] ?? false;
        if (!$approval_url) {
            error_log('CCPP: Failed to create PayPal subscription: No approval URL in response - ' . $response);
        }
        return $approval_url;
    }

    public function pricing_shortcode() {
        // Prevent shortcode execution in admin editor context to avoid critical errors
        if (is_admin() && !wp_doing_ajax()) {
            return '<p>' . esc_html__('Pricing shortcode cannot be previewed in the editor. Please view the page on the frontend.', 'ccpp') . '</p>';
        }

        try {
            // Debug: Output the values directly to the page for verification (remove in production)
            if (current_user_can('manage_options')) {
                echo '<div style="background: #f8d7da; color: #721c24; padding: 10px; margin-bottom: 10px;">';
                echo '<p>Debug Info (Visible to Admins Only):</p>';
                echo '<p>PayPal Client ID: ' . ($this->paypal_client_id ? esc_html(substr($this->paypal_client_id, 0, 5) . '...') : 'Not set') . '</p>';
                echo '<p>PayPal Secret: ' . ($this->paypal_secret ? 'Set (hidden for security)' : 'Not set') . '</p>';
                echo '<p>PayPal Mode: ' . esc_html($this->paypal_mode) . '</p>';
                echo '<p>Protection Enabled: ' . (get_option('ccpp_protection_enabled', 0) ? 'Yes' : 'No') . '</p>';
                echo '</div>';
            }

            if (empty($this->paypal_client_id) || empty($this->paypal_secret)) {
                $settings_url = admin_url('admin.php?page=ccpp_settings');
                return '<div class="text-red-500 p-4 bg-red-100 rounded-lg">' . esc_html__('PayPal Client ID and Secret are not configured. Please set them in the plugin settings: ', 'ccpp') . '<a href="' . esc_url($settings_url) . '" class="underline">Go to Settings</a></div>';
            }

            ob_start();
            ?>
            <div class="max-w-4xl mx-auto p-6 bg-white shadow-lg rounded-lg">
                <h2 class="text-2xl font-bold mb-4"><?php _e('Pricing Plans', 'ccpp'); ?></h2>
                <div class="mb-8">
                    <h3 class="text-xl font-semibold mb-2"><?php _e('Monthly Plans', 'ccpp'); ?></h3>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <!-- Silver Monthly -->
                        <div class="p-4 bg-gray-100 rounded-lg">
                            <h4 class="text-lg font-semibold"><?php _e('Silver - $5/Month', 'ccpp'); ?></h4>
                            <p class="text-gray-700"><?php _e('Access Silver content with a monthly subscription of $5.', 'ccpp'); ?></p>
                            <a href="#" class="ccpp-paypal-button mt-4 p-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 w-full text-center" data-plan="silver" data-cycle="monthly" data-amount="5.00"><?php _e('Subscribe Now', 'ccpp'); ?></a>
                        </div>
                        <!-- Premium Monthly -->
                        <div class="p-4 bg-gray-100 rounded-lg">
                            <h4 class="text-lg font-semibold"><?php _e('Premium - $10/Month', 'ccpp'); ?></h4>
                            <p class="text-gray-700"><?php _e('Access Premium content with a monthly subscription of $10.', 'ccpp'); ?></p>
                            <a href="#" class="ccpp-paypal-button mt-4 p-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 w-full text-center" data-plan="premium" data-cycle="monthly" data-amount="10.00"><?php _e('Subscribe Now', 'ccpp'); ?></a>
                        </div>
                        <!-- Platinum Monthly -->
                        <div class="p-4 bg-gray-100 rounded-lg">
                            <h4 class="text-lg font-semibold"><?php _e('Platinum - $15/Month', 'ccpp'); ?></h4>
                            <p class="text-gray-700"><?php _e('Access Platinum content with a monthly subscription of $15.', 'ccpp'); ?></p>
                            <a href="#" class="ccpp-paypal-button mt-4 p-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 w-full text-center" data-plan="platinum" data-cycle="monthly" data-amount="15.00"><?php _e('Subscribe Now', 'ccpp'); ?></a>
                        </div>
                    </div>
                </div>
                <div class="mb-8">
                    <h3 class="text-xl font-semibold mb-2"><?php _e('Yearly Plans', 'ccpp'); ?></h3>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <!-- Silver Yearly -->
                        <div class="p-4 bg-gray-100 rounded-lg">
                            <h4 class="text-lg font-semibold"><?php _e('Silver - $50/Year', 'ccpp'); ?></h4>
                            <p class="text-gray-700"><?php _e('Access Silver content with a yearly subscription of $50.', 'ccpp'); ?></p>
                            <a href="#" class="ccpp-paypal-button mt-4 p-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 w-full text-center" data-plan="silver" data-cycle="yearly" data-amount="50.00"><?php _e('Subscribe Now', 'ccpp'); ?></a>
                        </div>
                        <!-- Premium Yearly -->
                        <div class="p-4 bg-gray-100 rounded-lg">
                            <h4 class="text-lg font-semibold"><?php _e('Premium - $80/Year', 'ccpp'); ?></h4>
                            <p class="text-gray-700"><?php _e('Access Premium content with a yearly subscription of $80.', 'ccpp'); ?></p>
                            <a href="#" class="ccpp-paypal-button mt-4 p-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 w-full text-center" data-plan="premium" data-cycle="yearly" data-amount="80.00"><?php _e('Subscribe Now', 'ccpp'); ?></a>
                        </div>
                        <!-- Platinum Yearly -->
                        <div class="p-4 bg-gray-100 rounded-lg">
                            <h4 class="text-lg font-semibold"><?php _e('Platinum - $120/Year', 'ccpp'); ?></h4>
                            <p class="text-gray-700"><?php _e('Access Platinum content with a yearly subscription of $120.', 'ccpp'); ?></p>
                            <a href="#" class="ccpp-paypal-button mt-4 p-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 w-full text-center" data-plan="platinum" data-cycle="yearly" data-amount="120.00"><?php _e('Subscribe Now', 'ccpp'); ?></a>
                        </div>
                    </div>
                </div>
                <div class="mb-8">
                    <h3 class="text-xl font-semibold mb-2"><?php _e('Lifetime Plans', 'ccpp'); ?></h3>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <!-- Silver Lifetime -->
                        <div class="p-4 bg-gray-100 rounded-lg">
                            <h4 class="text-lg font-semibold"><?php _e('Silver - $200/Lifetime', 'ccpp'); ?></h4>
                            <p class="text-gray-700"><?php _e('Access Silver content for life with a one-time payment of $200.', 'ccpp'); ?></p>
                            <a href="#" class="ccpp-paypal-button mt-4 p-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 w-full text-center" data-plan="silver" data-cycle="lifetime" data-amount="200.00"><?php _e('Subscribe Now', 'ccpp'); ?></a>
                        </div>
                        <!-- Premium Lifetime -->
                        <div class="p-4 bg-gray-100 rounded-lg">
                            <h4 class="text-lg font-semibold"><?php _e('Premium - $350/Lifetime', 'ccpp'); ?></h4>
                            <p class="text-gray-700"><?php _e('Access Premium content for life with a one-time payment of $350.', 'ccpp'); ?></p>
                            <a href="#" class="ccpp-paypal-button mt-4 p-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 w-full text-center" data-plan="premium" data-cycle="lifetime" data-amount="350.00"><?php _e('Subscribe Now', 'ccpp'); ?></a>
                        </div>
                        <!-- Platinum Lifetime -->
                        <div class="p-4 bg-gray-100 rounded-lg">
                            <h4 class="text-lg font-semibold"><?php _e('Platinum - $500/Lifetime', 'ccpp'); ?></h4>
                            <p class="text-gray-700"><?php _e('Access Platinum content for life with a one-time payment of $500.', 'ccpp'); ?></p>
                            <a href="#" class="ccpp-paypal-button mt-4 p-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 w-full text-center" data-plan="platinum" data-cycle="lifetime" data-amount="500.00"><?php _e('Subscribe Now', 'ccpp'); ?></a>
                        </div>
                    </div>
                </div>
                <div class="mb-8">
                    <h3 class="text-xl font-semibold mb-2"><?php _e('One-Time Payment', 'ccpp'); ?></h3>
                    <div class="grid grid-cols-1 gap-6">
                        <div class="p-4 bg-gray-100 rounded-lg">
                            <h4 class="text-lg font-semibold"><?php _e('Basic Access - $1 (One-Time)', 'ccpp'); ?></h4>
                            <p class="text-gray-700"><?php _e('Get basic access with a one-time payment of $1.', 'ccpp'); ?></p>
                            <a href="#" class="ccpp-paypal-button mt-4 p-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 w-full text-center" data-plan="basic" data-cycle="one-time" data-amount="1.00"><?php _e('Subscribe Now', 'ccpp'); ?></a>
                        </div>
                    </div>
                </div>
                <div>
                    <h3 class="text-xl font-semibold mb-2"><?php _e('Unlock Individual Posts', 'ccpp'); ?></h3>
                    <div class="space-y-4">
                        <?php
                        $args = [
                            'post_type' => 'post',
                            'posts_per_page' => -1,
                            'meta_query' => [
                                [
                                    'key' => 'ccpp_post_payment_enabled',
                                    'value' => '1',
                                    'compare' => '='
                                ]
                            ]
                        ];
                        $posts = new WP_Query($args);
                        if ($posts->have_posts()) :
                            while ($posts->have_posts()) : $posts->the_post();
                                $amount = floatval(get_post_meta(get_the_ID(), 'ccpp_post_payment_amount', true));
                                if ($amount <= 0) continue;
                                ?>
                                <div class="p-4 bg-gray-100 rounded-lg">
                                    <h4 class="text-lg font-semibold"><?php the_title(); ?> - $<?php echo number_format($amount, 2); ?> (One-Time)</h4>
                                    <p class="text-gray-700"><?php _e('Unlock this post with a one-time payment.', 'ccpp'); ?></p>
                                    <a href="#" class="ccpp-paypal-button mt-4 p-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 w-full text-center" data-post-id="<?php the_ID(); ?>" data-cycle="one-time" data-amount="<?php echo esc_attr($amount); ?>"><?php _e('Subscribe Now', 'ccpp'); ?></a>
                                </div>
                                <?php
                            endwhile;
                            wp_reset_postdata();
                        else :
                            ?>
                            <p class="text-gray-700"><?php _e('No posts available for individual purchase at this time.', 'ccpp'); ?></p>
                            <?php
                        endif;
                        ?>
                    </div>
                </div>
            </div>
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    if (typeof ccpp_frontend === 'undefined') {
                        console.error('CCPP: ccpp_frontend object is not defined. Ensure scripts are enqueued properly.');
                        return;
                    }

                    document.querySelectorAll('.ccpp-paypal-button').forEach(button => {
                        button.addEventListener('click', function(e) {
                            e.preventDefault();
                            const plan = this.getAttribute('data-plan');
                            const cycle = this.getAttribute('data-cycle');
                            const amount = this.getAttribute('data-amount');
                            const postId = this.getAttribute('data-post-id');

                            let action = '';
                            if (cycle === 'monthly' || cycle === 'yearly') {
                                action = 'ccpp_create_subscription';
                            } else {
                                action = 'ccpp_create_order';
                            }

                            console.log('Initiating payment:', { action, plan, cycle, amount, postId });

                            jQuery.ajax({
                                url: ccpp_frontend.ajax_url,
                                type: 'POST',
                                data: {
                                    action: action,
                                    nonce: ccpp_frontend.nonce,
                                    plan: plan,
                                    cycle: cycle,
                                    amount: amount,
                                    post_id: postId
                                },
                                success: function(response) {
                                    console.log('AJAX Success:', response);
                                    if (response.success && response.data.url) {
                                        window.location.href = response.data.url;
                                    } else {
                                        console.error('Payment initiation failed:', response.data.message);
                                        alert('Payment initiation failed: ' + (response.data.message || 'Unknown error.'));
                                    }
                                },
                                error: function(xhr, status, error) {
                                    console.error('AJAX Error:', status, error, xhr.responseText);
                                    alert('Payment initiation failed: ' + (xhr.responseText || 'Check console for details.'));
                                }
                            });
                        });
                    });

                    // Toggle protection button (example implementation)
                    const toggleButton = document.querySelector('#ccpp-toggle-protection');
                    if (toggleButton) {
                        toggleButton.addEventListener('click', function() {
                            const enable = this.checked;
                            jQuery.post(ccpp_frontend.ajax_url, {
                                action: 'ccpp_toggle_protection',
                                nonce: ccpp_frontend.nonce,
                                enable: enable
                            }, function(response) {
                                if (response.success) {
                                    alert(response.data.message);
                                } else {
                                    alert('Error: ' + (response.data.message || 'Failed to toggle protection.'));
                                }
                            }).fail(function(xhr, status, error) {
                                console.error('Toggle Protection AJAX Error:', status, error);
                                alert('Toggle protection failed. Check console for details.');
                            });
                        });
                    }
                });
            </script>
            <?php
            return ob_get_clean();
        } catch (Exception $e) {
            error_log('CCPP: Pricing shortcode error: ' . $e->getMessage());
            return '<div class="text-red-500 p-4 bg-red-100 rounded-lg">' . esc_html__('Failed to load pricing: ' . $e->getMessage(), 'ccpp') . '</div>';
        }
    }

    public function process_payment() {
        try {
            if (!check_ajax_referer('ccpp_frontend_nonce', 'nonce', false)) {
                error_log('CCPP: Process payment failed - Invalid nonce.');
                wp_send_json_error(['message' => __('Security check failed. Please refresh the page and try again.', 'ccpp')]);
                return;
            }

            $subscription_id = sanitize_text_field($_POST['subscription_id'] ?? '');
            $order_id = sanitize_text_field($_POST['order_id'] ?? '');
            $payer_id = sanitize_text_field($_POST['payer_id'] ?? '');
            $plan = sanitize_text_field($_POST['plan'] ?? '');
            $billing_cycle = sanitize_text_field($_POST['billing_cycle'] ?? '');

            if (empty($this->paypal_client_id) || empty($this->paypal_secret)) {
                wp_send_json_error(['message' => __('PayPal Client ID and Secret are not configured.', 'ccpp')]);
                return;
            }

            if ($subscription_id) {
                $user_id = get_current_user_id();
                if ($user_id) {
                    global $wpdb;
                    $table = $wpdb->prefix . 'ccpp_subscriptions';
                    $expires_at = $billing_cycle === 'yearly' ? date('Y-m-d H:i:s', strtotime('+1 year')) : ($billing_cycle === 'monthly' ? date('Y-m-d H:i:s', strtotime('+1 month')) : null);
                    $wpdb->insert(
                        $table,
                        [
                            'user_id' => $user_id,
                            'plan' => $plan,
                            'subscription_id' => $subscription_id,
                            'status' => 'active',
                            'created_at' => current_time('mysql'),
                            'expires_at' => $expires_at
                        ],
                        ['%d', '%s', '%s', '%s', '%s', '%s']
                    );
                    if ($wpdb->last_error) {
                        wp_send_json_error(['message' => __('Database error: ' . $wpdb->last_error, 'ccpp')]);
                    } else {
                        wp_send_json_success(['message' => __('Subscription processed successfully.', 'ccpp')]);
                    }
                } else {
                    wp_send_json_error(['message' => __('User not logged in.', 'ccpp')]);
                }
            } elseif ($order_id && $payer_id) {
                $user_id = get_current_user_id();
                if ($user_id) {
                    global $wpdb;
                    $table = $wpdb->prefix . 'ccpp_subscriptions';
                    $expires_at = ($billing_cycle === 'lifetime') ? null : null;
                    $wpdb->insert(
                        $table,
                        [
                            'user_id' => $user_id,
                            'plan' => $plan,
                            'subscription_id' => $order_id,
                            'status' => 'active',
                            'created_at' => current_time('mysql'),
                            'expires_at' => $expires_at
                        ],
                        ['%d', '%s', '%s', '%s', '%s', '%s']
                    );
                    if ($wpdb->last_error) {
                        wp_send_json_error(['message' => __('Database error: ' . $wpdb->last_error, 'ccpp')]);
                    } else {
                        wp_send_json_success(['message' => __('Payment processed successfully.', 'ccpp')]);
                    }
                } else {
                    wp_send_json_error(['message' => __('User not logged in.', 'ccpp')]);
                }
            } else {
                wp_send_json_error(['message' => __('Invalid payment data.', 'ccpp')]);
            }
        } catch (Exception $e) {
            error_log('CCPP: Process payment error: ' . $e->getMessage());
            wp_send_json_error(['message' => __('Payment processing failed: ' . $e->getMessage(), 'ccpp')]);
        }
    }

    public function process_post_payment() {
        try {
            if (!check_ajax_referer('ccpp_frontend_nonce', 'nonce', false)) {
                error_log('CCPP: Process post payment failed - Invalid nonce.');
                wp_send_json_error(['message' => __('Security check failed. Please refresh the page and try again.', 'ccpp')]);
                return;
            }

            $order_id = sanitize_text_field($_POST['order_id'] ?? '');
            $payer_id = sanitize_text_field($_POST['payer_id'] ?? '');
            $post_id = intval($_POST['post_id'] ?? 0);

            if (empty($this->paypal_client_id) || empty($this->paypal_secret)) {
                wp_send_json_error(['message' => __('PayPal Client ID and Secret are not configured.', 'ccpp')]);
                return;
            }

            if (empty($order_id) || empty($payer_id) || !$post_id) {
                wp_send_json_error(['message' => __('Invalid payment data.', 'ccpp')]);
            }

            $user_id = get_current_user_id();
            if ($user_id) {
                $transient_key = 'ccpp_post_access_' . $post_id . '_' . $user_id;
                set_transient($transient_key, true, 0); // Permanent access after payment
                wp_send_json_success(['message' => __('Post unlocked successfully.', 'ccpp')]);
            } else {
                wp_send_json_error(['message' => __('User not logged in.', 'ccpp')]);
            }
        } catch (Exception $e) {
            error_log('CCPP: Process post payment error: ' . $e->getMessage());
            wp_send_json_error(['message' => __('Payment processing failed: ' . $e->getMessage(), 'ccpp')]);
        }
    }

    public function create_order() {
        try {
            if (!check_ajax_referer('ccpp_frontend_nonce', 'nonce', false)) {
                error_log('CCPP: Create order failed - Invalid nonce.');
                wp_send_json_error(['message' => __('Security check failed. Please refresh the page and try again.', 'ccpp')]);
                return;
            }

            $amount = floatval($_POST['amount'] ?? 0);
            $post_id = intval($_POST['post_id'] ?? 0);

            error_log('CCPP: Creating order - Amount: ' . $amount . ', Post ID: ' . $post_id);

            if (empty($amount) || $amount <= 0) {
                error_log('CCPP: Create order failed - Invalid amount.');
                wp_send_json_error(['message' => __('Invalid amount.', 'ccpp')]);
                return;
            }

            if (empty($this->paypal_client_id) || empty($this->paypal_secret)) {
                error_log('CCPP: Create order failed - PayPal configuration missing.');
                wp_send_json_error(['message' => __('PayPal Client ID and Secret are not configured.', 'ccpp')]);
                return;
            }

            $approval_url = $this->create_paypal_order($amount);
            if ($approval_url) {
                error_log('CCPP: Order created successfully - Approval URL: ' . $approval_url);
                wp_send_json_success(['url' => $approval_url]);
            } else {
                error_log('CCPP: Create order failed - No approval URL returned.');
                wp_send_json_error(['message' => __('Failed to create PayPal order. Check logs for details.', 'ccpp')]);
            }
        } catch (Exception $e) {
            error_log('CCPP: Create order error: ' . $e->getMessage());
            wp_send_json_error(['message' => __('Failed to create order: ' . $e->getMessage(), 'ccpp')]);
        }
    }

    public function create_subscription() {
        try {
            if (!check_ajax_referer('ccpp_frontend_nonce', 'nonce', false)) {
                error_log('CCPP: Create subscription failed - Invalid nonce.');
                wp_send_json_error(['message' => __('Security check failed. Please refresh the page and try again.', 'ccpp')]);
                return;
            }

            $plan = sanitize_text_field($_POST['plan'] ?? '');
            $cycle = sanitize_text_field($_POST['cycle'] ?? '');

            error_log('CCPP: Creating subscription - Plan: ' . $plan . ', Cycle: ' . $cycle);

            if (empty($plan) || empty($cycle)) {
                error_log('CCPP: Create subscription failed - Invalid plan or cycle.');
                wp_send_json_error(['message' => __('Invalid plan or billing cycle.', 'ccpp')]);
                return;
            }

            if (empty($this->paypal_client_id) || empty($this->paypal_secret)) {
                error_log('CCPP: Create subscription failed - PayPal configuration missing.');
                wp_send_json_error(['message' => __('PayPal Client ID and Secret are not configured.', 'ccpp')]);
                return;
            }

            // Retrieve plan IDs from settings
            $plan_ids = get_option('ccpp_paypal_plan_ids', []);
            if (empty($plan_ids) || !is_array($plan_ids)) {
                $plan_ids = [
                    'silver' => ['monthly' => '', 'yearly' => ''],
                    'premium' => ['monthly' => '', 'yearly' => ''],
                    'platinum' => ['monthly' => '', 'yearly' => '']
                ];
                error_log('CCPP: Create subscription - No plan IDs found in settings. Using default empty values.');
            }

            $plan_id = isset($plan_ids[$plan][$cycle]) ? $plan_ids[$plan][$cycle] : '';
            if (empty($plan_id)) {
                error_log('CCPP: Create subscription failed - Invalid or missing plan ID for ' . $plan . ' (' . $cycle . ').');
                wp_send_json_error(['message' => __('Invalid subscription plan. Please configure plan IDs in settings.', 'ccpp')]);
                return;
            }

            $approval_url = $this->create_paypal_subscription($plan_id);
            if ($approval_url) {
                error_log('CCPP: Subscription created successfully - Approval URL: ' . $approval_url);
                wp_send_json_success(['url' => $approval_url]);
            } else {
                error_log('CCPP: Create subscription failed - No approval URL returned.');
                wp_send_json_error(['message' => __('Failed to create PayPal subscription. Check logs for details.', 'ccpp')]);
            }
        } catch (Exception $e) {
            error_log('CCPP: Create subscription error: ' . $e->getMessage());
            wp_send_json_error(['message' => __('Failed to create subscription: ' . $e->getMessage(), 'ccpp')]);
        }
    }
}

add_action('wp_ajax_ccpp_create_order', ['CCPP_Payment', 'create_order']);
add_action('wp_ajax_nopriv_ccpp_create_order', ['CCPP_Payment', 'create_order']);
add_action('wp_ajax_ccpp_create_subscription', ['CCPP_Payment', 'create_subscription']);
add_action('wp_ajax_nopriv_ccpp_create_subscription', ['CCPP_Payment', 'create_subscription']);
?>