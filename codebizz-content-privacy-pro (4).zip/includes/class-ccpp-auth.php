<?php
if (!defined('ABSPATH')) {
    exit;
}

class CCPP_Auth {
    public function init() {
        try {
            // Register shortcodes
            add_shortcode('ccpp_login', [$this, 'login_shortcode']);
            add_shortcode('ccpp_register', [$this, 'register_shortcode']);
            add_shortcode('ccpp_forgot_password', [$this, 'forgot_password_shortcode']);
            add_shortcode('ccpp_user_profile', [$this, 'user_profile_shortcode']);
            add_shortcode('ccpp_account', [$this, 'account_shortcode']);
            add_shortcode('ccpp_logout', [$this, 'logout_shortcode']);
            add_shortcode('ccpp_member_directory', [$this, 'member_directory_shortcode']);
            add_shortcode('ccpp_password_reset', [$this, 'password_reset_shortcode']);

            // Handle AJAX requests
            add_action('wp_ajax_ccpp_login', [$this, 'ajax_login']);
            add_action('wp_ajax_nopriv_ccpp_login', [$this, 'ajax_login']);
            add_action('wp_ajax_ccpp_register', [$this, 'ajax_register']);
            add_action('wp_ajax_nopriv_ccpp_register', [$this, 'ajax_register']);
            add_action('wp_ajax_ccpp_forgot_password', [$this, 'ajax_forgot_password']);
            add_action('wp_ajax_nopriv_ccpp_forgot_password', [$this, 'ajax_forgot_password']);
            add_action('wp_ajax_ccpp_update_profile', [$this, 'ajax_update_profile']);
            add_action('wp_ajax_ccpp_update_account', [$this, 'ajax_update_account']);

            // Handle email verification and password reset
            add_action('init', [$this, 'handle_email_verification']);
            add_action('init', [$this, 'handle_password_reset']);

            // Enqueue auth scripts
            add_action('wp_enqueue_scripts', [$this, 'enqueue_scripts']);
        } catch (Exception $e) {
            error_log('CCPP: Auth init error: ' . $e->getMessage());
        }
    }

    public function enqueue_scripts() {
        try {
            // Enqueue Tailwind CSS and SweetAlert2 via CDN
            wp_enqueue_style('tailwindcss', 'https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css', [], '2.2.19');
            wp_enqueue_script('sweetalert2', 'https://cdn.jsdelivr.net/npm/sweetalert2@11', [], '11.0', true);
            wp_enqueue_script('ccpp-auth-script', CCPP_URL . 'assets/js/auth.js', ['jquery', 'sweetalert2'], CCPP_VERSION, true);
            wp_localize_script('ccpp-auth-script', 'ccpp_auth', [
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('ccpp_auth_nonce'),
            ]);
        } catch (Exception $e) {
            error_log('CCPP: Auth enqueue scripts error: ' . $e->getMessage());
        }
    }

    public function login_shortcode() {
        try {
            if (is_user_logged_in()) {
                return '<div class="text-green-500 p-4 bg-green-100 rounded-lg">' . esc_html__('You are already logged in.', 'ccpp') . '</div>';
            }

            ob_start();
            ?>
            <div class="max-w-md mx-auto p-6 bg-white shadow-lg rounded-lg">
                <div id="ccpp-login-message" class="hidden p-4 mb-4 rounded-lg"></div>
                <form id="ccpp-login-form" method="post" class="space-y-4">
                    <div>
                        <input type="text" name="username" placeholder="<?php _e('Username or Email', 'ccpp'); ?>" class="w-full p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
                    </div>
                    <div>
                        <input type="password" name="password" placeholder="<?php _e('Password', 'ccpp'); ?>" class="w-full p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
                    </div>
                    <div>
                        <input type="submit" value="<?php _e('Log In', 'ccpp'); ?>" class="w-full p-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600">
                    </div>
                    <div class="text-center">
                        <a href="<?php echo esc_url(get_permalink(get_page_by_path('password-reset')) ?: home_url('/password-reset')); ?>" class="text-blue-500 hover:underline"><?php _e('Forgot Password?', 'ccpp'); ?></a>
                    </div>
                    <div class="text-center">
                        <p><?php _e('Don’t have an account?', 'ccpp'); ?> <a href="<?php echo esc_url(get_permalink(get_page_by_path('register')) ?: home_url('/register')); ?>" class="text-blue-500 hover:underline"><?php _e('Register', 'ccpp'); ?></a></p>
                    </div>
                </form>
            </div>
            <?php
            return ob_get_clean();
        } catch (Exception $e) {
            error_log('CCPP: Login shortcode error: ' . $e->getMessage());
            return '<div class="text-red-500 p-4 bg-red-100 rounded-lg">' . esc_html__('Failed to load login form.', 'ccpp') . '</div>';
        }
    }

    public function ajax_login() {
        try {
            check_ajax_referer('ccpp_auth_nonce', 'nonce');
            $username = sanitize_text_field($_POST['username'] ?? '');
            $password = $_POST['password'] ?? '';

            if (empty($username) || empty($password)) {
                wp_send_json_error(['message' => __('Please fill in all fields.', 'ccpp'), 'type' => 'fields_missing']);
            }

            $user = wp_signon([
                'user_login' => $username,
                'user_password' => $password,
                'remember' => true,
            ]);

            global $wpdb;
            $ip_address = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
            $attempt_type = is_wp_error($user) ? 'failed_login' : 'successful_login';
            $wpdb->insert(
                $wpdb->prefix . 'ccpp_logs',
                [
                    'user_id' => is_wp_error($user) ? 0 : $user->ID,
                    'ip_address' => $ip_address,
                    'attempt_type' => $attempt_type,
                    'attempt_time' => current_time('mysql'),
                ],
                ['%d', '%s', '%s', '%s']
            );

            if (is_wp_error($user)) {
                error_log('CCPP: Login failed for ' . $username . ': ' . $user->get_error_message());
                wp_send_json_error(['message' => __('Invalid username or password.', 'ccpp'), 'type' => 'invalid_credentials']);
            }

            // Check email verification status
            $status = get_user_meta($user->ID, 'ccpp_status', true);
            if ($status === 'awaiting_email_confirmation') {
                wp_send_json_error(['message' => __('Please verify your email before logging in.', 'ccpp'), 'type' => 'unverified']);
            }

            wp_set_current_user($user->ID);
            wp_set_auth_cookie($user->ID, true);
            wp_send_json_success(['redirect' => home_url()]);
        } catch (Exception $e) {
            error_log('CCPP: AJAX login error: ' . $e->getMessage());
            wp_send_json_error(['message' => __('An error occurred during login.', 'ccpp'), 'type' => 'general_error']);
        }
    }

    public function register_shortcode() {
        try {
            if (!get_option('ccpp_registration_enabled', '1')) {
                return '<div class="text-red-500 p-4 bg-red-100 rounded-lg">' . esc_html__('Registration is disabled.', 'ccpp') . '</div>';
            }

            if (is_user_logged_in()) {
                return '<div class="text-green-500 p-4 bg-green-100 rounded-lg">' . esc_html__('You are already registered and logged in.', 'ccpp') . '</div>';
            }

            ob_start();
            ?>
            <div class="max-w-md mx-auto p-6 bg-white shadow-lg rounded-lg">
                <div id="ccpp-register-message" class="hidden p-4 mb-4 rounded-lg"></div>
                <form id="ccpp-register-form" method="post" class="space-y-4">
                    <div>
                        <input type="text" name="username" placeholder="<?php _e('Username', 'ccpp'); ?>" class="w-full p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
                    </div>
                    <div>
                        <input type="email" name="email" placeholder="<?php _e('Email', 'ccpp'); ?>" class="w-full p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
                    </div>
                    <div>
                        <input type="password" name="password" placeholder="<?php _e('Password', 'ccpp'); ?>" class="w-full p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
                    </div>
                    <div>
                        <input type="password" name="confirm_password" placeholder="<?php _e('Confirm Password', 'ccpp'); ?>" class="w-full p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
                    </div>
                    <div>
                        <input type="text" name="first_name" placeholder="<?php _e('First Name (Optional)', 'ccpp'); ?>" class="w-full p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>
                    <div>
                        <input type="text" name="last_name" placeholder="<?php _e('Last Name (Optional)', 'ccpp'); ?>" class="w-full p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>
                    <div>
                        <input type="submit" value="<?php _e('Register', 'ccpp'); ?>" class="w-full p-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600">
                    </div>
                    <div class="text-center">
                        <p><?php _e('Already have an account?', 'ccpp'); ?> <a href="<?php echo esc_url(get_permalink(get_page_by_path('login')) ?: home_url('/login')); ?>" class="text-blue-500 hover:underline"><?php _e('Log In', 'ccpp'); ?></a></p>
                    </div>
                </form>
            </div>
            <?php
            return ob_get_clean();
        } catch (Exception $e) {
            error_log('CCPP: Register shortcode error: ' . $e->getMessage());
            return '<div class="text-red-500 p-4 bg-red-100 rounded-lg">' . esc_html__('Failed to load registration form.', 'ccpp') . '</div>';
        }
    }

    public function ajax_register() {
        try {
            check_ajax_referer('ccpp_auth_nonce', 'nonce');

            if (!get_option('ccpp_registration_enabled', '1')) {
                wp_send_json_error(['message' => __('Registration is disabled.', 'ccpp')]);
            }

            $username = sanitize_user($_POST['username'] ?? '');
            $email = sanitize_email($_POST['email'] ?? '');
            $password = $_POST['password'] ?? '';
            $confirm_password = $_POST['confirm_password'] ?? '';
            $first_name = sanitize_text_field($_POST['first_name'] ?? '');
            $last_name = sanitize_text_field($_POST['last_name'] ?? '');

            if (empty($username) || empty($email) || empty($password) || empty($confirm_password)) {
                wp_send_json_error(['message' => __('Please fill in all required fields.', 'ccpp')]);
            }

            if ($password !== $confirm_password) {
                wp_send_json_error(['message' => __('Passwords do not match.', 'ccpp')]);
            }

            if (username_exists($username)) {
                wp_send_json_error(['message' => __('Username already exists.', 'ccpp')]);
            }

            if (email_exists($email)) {
                wp_send_json_error(['message' => __('Email already exists.', 'ccpp')]);
            }

            $user_id = wp_create_user($username, $password, $email);
            if (is_wp_error($user_id)) {
                error_log('CCPP: User creation failed: ' . $user_id->get_error_message());
                wp_send_json_error(['message' => __('Failed to create user.', 'ccpp')]);
            }

            if ($first_name) {
                update_user_meta($user_id, 'first_name', $first_name);
            }
            if ($last_name) {
                update_user_meta($user_id, 'last_name', $last_name);
            }
            wp_update_user(['ID' => $user_id, 'role' => 'subscriber']);
            update_user_meta($user_id, 'ccpp_status', get_option('ccpp_email_verification', '1') ? 'awaiting_email_confirmation' : 'pending');

            global $wpdb;
            $wpdb->insert(
                $wpdb->prefix . 'ccpp_subscriptions',
                [
                    'user_id' => $user_id,
                    'plan' => 'free',
                    'subscription_id' => 'FREE-' . uniqid(),
                    'status' => 'active',
                    'created_at' => current_time('mysql'),
                    'expires_at' => null,
                ],
                ['%d', '%s', '%s', '%s', '%s', '%s']
            );

            if (get_option('ccpp_email_verification', '1')) {
                $token = wp_generate_uuid4();
                $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));
                $wpdb->insert(
                    $wpdb->prefix . 'ccpp_email_verifications',
                    [
                        'user_id' => $user_id,
                        'token' => $token,
                        'created_at' => current_time('mysql'),
                        'expires_at' => $expires,
                    ],
                    ['%d', '%s', '%s', '%s']
                );

                $verify_url = add_query_arg(['ccpp_verify' => $token], home_url());
                $subject = __('Verify Your Email Address', 'ccpp');
                $message = sprintf(
                    __('Please verify your email by clicking the link below:<br><a href="%s">%s</a><br>The link will expire in 1 hour.', 'ccpp'),
                    esc_url($verify_url),
                    esc_url($verify_url)
                );
                $headers = ['Content-Type: text/html; charset=UTF-8'];
                $sent = wp_mail($email, $subject, $message, $headers);
                if (!$sent) {
                    error_log('CCPP: Failed to send verification email to ' . $email);
                    wp_send_json_error(['message' => __('Failed to send verification email. Please try again.', 'ccpp')]);
                }
                wp_send_json_success(['message' => __('Registration successful! Please check your email to verify your account.', 'ccpp')]);
            }

            $wpdb->insert(
                $wpdb->prefix . 'ccpp_logs',
                [
                    'user_id' => $user_id,
                    'ip_address' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
                    'attempt_type' => 'successful_registration',
                    'attempt_time' => current_time('mysql'),
                ],
                ['%d', '%s', '%s', '%s']
            );

            wp_set_current_user($user_id);
            wp_set_auth_cookie($user_id, true);
            wp_send_json_success(['redirect' => home_url()]);
        } catch (Exception $e) {
            error_log('CCPP: AJAX register error: ' . $e->getMessage());
            wp_send_json_error(['message' => __('An error occurred during registration.', 'ccpp')]);
        }
    }

    public function handle_email_verification() {
        try {
            if (!isset($_GET['ccpp_verify'])) {
                return;
            }

            $token = sanitize_text_field($_GET['ccpp_verify']);
            global $wpdb;
            $table = $wpdb->prefix . 'ccpp_email_verifications';
            $verification = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM $table WHERE token = %s AND expires_at > %s",
                $token,
                current_time('mysql')
            ));

            if (!$verification) {
                wp_die(__('Invalid or expired verification link.', 'ccpp'));
            }

            update_user_meta($verification->user_id, 'ccpp_email_verified', '1');
            update_user_meta($verification->user_id, 'ccpp_status', 'pending');
            $wpdb->delete($table, ['id' => $verification->id], ['%d']);

            wp_redirect(add_query_arg('ccpp_verified', '1', home_url()));
            exit;
        } catch (Exception $e) {
            error_log('CCPP: Email verification error: ' . $e->getMessage());
            wp_die(__('An error occurred during email verification.', 'ccpp'));
        }
    }

    public function password_reset_shortcode() {
        try {
            if (!is_user_logged_in()) {
                wp_redirect(get_permalink(get_page_by_path('login')) ?: home_url('/login'));
                exit;
            }

            ob_start();
            ?>
            <div class="max-w-md mx-auto p-6 bg-white shadow-lg rounded-lg">
                <div id="ccpp-password-reset-message" class="hidden p-4 mb-4 rounded-lg"></div>
                <form id="ccpp-password-reset-form" method="post" class="space-y-4">
                    <div>
                        <input type="password" name="new_password" placeholder="<?php _e('New Password', 'ccpp'); ?>" class="w-full p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
                    </div>
                    <div>
                        <input type="password" name="confirm_password" placeholder="<?php _e('Confirm Password', 'ccpp'); ?>" class="w-full p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
                    </div>
                    <div>
                        <input type="submit" value="<?php _e('Reset Password', 'ccpp'); ?>" class="w-full p-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600">
                    </div>
                </form>
            </div>
            <?php
            return ob_get_clean();
        } catch (Exception $e) {
            error_log('CCPP: Password reset shortcode error: ' . $e->getMessage());
            return '<div class="text-red-500 p-4 bg-red-100 rounded-lg">' . esc_html__('Failed to load password reset form.', 'ccpp') . '</div>';
        }
    }

    public function forgot_password_shortcode() {
        try {
            if (is_user_logged_in()) {
                return '<div class="text-green-500 p-4 bg-green-100 rounded-lg">' . esc_html__('You are already logged in.', 'ccpp') . '</div>';
            }

            ob_start();
            ?>
            <div class="max-w-md mx-auto p-6 bg-white shadow-lg rounded-lg">
                <div id="ccpp-forgot-password-message" class="hidden p-4 mb-4 rounded-lg"></div>
                <form id="ccpp-forgot-password-form" method="post" class="space-y-4">
                    <div>
                        <input type="email" name="email" placeholder="<?php _e('Email', 'ccpp'); ?>" class="w-full p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
                    </div>
                    <div>
                        <input type="submit" value="<?php _e('Reset Password', 'ccpp'); ?>" class="w-full p-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600">
                    </div>
                    <div class="text-center">
                        <a href="<?php echo esc_url(get_permalink(get_page_by_path('login')) ?: home_url('/login')); ?>" class="text-blue-500 hover:underline"><?php _e('Back to Log In', 'ccpp'); ?></a>
                    </div>
                </form>
            </div>
            <?php
            return ob_get_clean();
        } catch (Exception $e) {
            error_log('CCPP: Forgot password shortcode error: ' . $e->getMessage());
            return '<div class="text-red-500 p-4 bg-red-100 rounded-lg">' . esc_html__('Failed to load forgot password form.', 'ccpp') . '</div>';
        }
    }

    public function ajax_forgot_password() {
        try {
            check_ajax_referer('ccpp_auth_nonce', 'nonce');
            $email = sanitize_email($_POST['email'] ?? '');

            if (empty($email)) {
                wp_send_json_error(['message' => __('Please enter an email address.', 'ccpp')]);
            }

            $user = get_user_by('email', $email);
            if (!$user) {
                wp_send_json_error(['message' => __('No user found with that email address.', 'ccpp')]);
            }

            $reset_key = get_password_reset_key($user);
            if (is_wp_error($reset_key)) {
                error_log('CCPP: Password reset key generation failed: ' . $reset_key->get_error_message());
                wp_send_json_error(['message' => __('Failed to generate reset link.', 'ccpp')]);
            }

            $reset_url = add_query_arg(
                ['key' => $reset_key, 'login' => rawurlencode($user->user_login)],
                get_permalink(get_page_by_path('password-reset')) ?: home_url('/password-reset')
            );
            $subject = __('Password Reset Request', 'ccpp');
            $message = sprintf(
                __('To reset your password, click the link below:<br><a href="%s">%s</a><br>The link will expire in 1 hour.', 'ccpp'),
                esc_url($reset_url),
                esc_url($reset_url)
            );
            $headers = ['Content-Type: text/html; charset=UTF-8'];
            $sent = wp_mail($email, $subject, $message, $headers);
            if (!$sent) {
                error_log('CCPP: Failed to send password reset email to ' . $email);
                wp_send_json_error(['message' => __('Failed to send reset email.', 'ccpp')]);
            }

            global $wpdb;
            $wpdb->insert(
                $wpdb->prefix . 'ccpp_logs',
                [
                    'user_id' => $user->ID,
                    'ip_address' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
                    'attempt_type' => 'password_reset_request',
                    'attempt_time' => current_time('mysql'),
                ],
                ['%d', '%s', '%s', '%s']
            );

            wp_send_json_success(['message' => __('Password reset email sent. Please check your inbox.', 'ccpp')]);
        } catch (Exception $e) {
            error_log('CCPP: AJAX forgot password error: ' . $e->getMessage());
            wp_send_json_error(['message' => __('An error occurred during password reset.', 'ccpp')]);
        }
    }

    public function user_profile_shortcode() {
        try {
            if (!is_user_logged_in()) {
                wp_redirect(get_permalink(get_page_by_path('login')) ?: home_url('/login'));
                exit;
            }

            $user = wp_get_current_user();
            $plan = ccpp_get_user_plan($user->ID) ?: 'free';
            ob_start();
            ?>
            <div class="max-w-2xl mx-auto p-6 bg-white shadow-lg rounded-lg">
                <div id="ccpp-user-profile-message" class="hidden p-4 mb-4 rounded-lg"></div>
                <form id="ccpp-user-profile-form" method="post" class="space-y-6">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700"><?php _e('First Name', 'ccpp'); ?></label>
                            <input type="text" name="first_name" value="<?php echo esc_attr($user->first_name); ?>" class="w-full p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700"><?php _e('Last Name', 'ccpp'); ?></label>
                            <input type="text" name="last_name" value="<?php echo esc_attr($user->last_name); ?>" class="w-full p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700"><?php _e('Email', 'ccpp'); ?></label>
                        <input type="email" name="email" value="<?php echo esc_attr($user->user_email); ?>" class="w-full p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700"><?php _e('New Password (leave blank to keep current)', 'ccpp'); ?></label>
                        <input type="password" name="new_password" class="w-full p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700"><?php _e('Confirm New Password', 'ccpp'); ?></label>
                        <input type="password" name="confirm_password" class="w-full p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>
                    <div>
                        <input type="submit" value="<?php _e('Update Profile', 'ccpp'); ?>" class="w-full p-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600">
                    </div>
                </form>
                <div class="mt-6">
                    <h3 class="text-xl font-semibold mb-2"><?php _e('Subscription Plan', 'ccpp'); ?></h3>
                    <p class="text-gray-700"><?php printf(__('Current Plan: %s', 'ccpp'), esc_html(ucfirst($plan))); ?></p>
                    <a href="<?php echo esc_url(get_permalink(get_page_by_path('pricing')) ?: home_url('/pricing')); ?>" class="inline-block mt-2 p-2 bg-green-500 text-white rounded-lg hover:bg-green-600"><?php _e('Upgrade Plan', 'ccpp'); ?></a>
                </div>
            </div>
            <?php
            return ob_get_clean();
        } catch (Exception $e) {
            error_log('CCPP: User profile shortcode error: ' . $e->getMessage());
            return '<div class="text-red-500 p-4 bg-red-100 rounded-lg">' . esc_html__('Failed to load user profile form.', 'ccpp') . '</div>';
        }
    }

    public function ajax_update_profile() {
        try {
            check_ajax_referer('ccpp_auth_nonce', 'nonce');
            $user_id = get_current_user_id();
            $first_name = sanitize_text_field($_POST['first_name'] ?? '');
            $last_name = sanitize_text_field($_POST['last_name'] ?? '');
            $email = sanitize_email($_POST['email'] ?? '');
            $new_password = $_POST['new_password'] ?? '';
            $confirm_password = $_POST['confirm_password'] ?? '';

            if (empty($email)) {
                wp_send_json_error(['message' => __('Email is required.', 'ccpp')]);
            }

            if (email_exists($email) && $email !== wp_get_current_user()->user_email) {
                wp_send_json_error(['message' => __('Email already exists.', 'ccpp')]);
            }

            if (!empty($new_password) && $new_password !== $confirm_password) {
                wp_send_json_error(['message' => __('Passwords do not match.', 'ccpp')]);
            }

            $user_data = [
                'ID' => $user_id,
                'user_email' => $email,
                'first_name' => $first_name,
                'last_name' => $last_name,
            ];
            wp_update_user($user_data);

            if (!empty($new_password)) {
                wp_set_password($new_password, $user_id);
            }

            global $wpdb;
            $wpdb->insert(
                $wpdb->prefix . 'ccpp_logs',
                [
                    'user_id' => $user_id,
                    'ip_address' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
                    'attempt_type' => 'profile_update',
                    'attempt_time' => current_time('mysql'),
                ],
                ['%d', '%s', '%s', '%s']
            );

            wp_send_json_success(['message' => __('Profile updated successfully.', 'ccpp')]);
        } catch (Exception $e) {
            error_log('CCPP: AJAX update profile error: ' . $e->getMessage());
            wp_send_json_error(['message' => __('An error occurred during profile update.', 'ccpp')]);
        }
    }

    public function account_shortcode() {
        try {
            if (!is_user_logged_in()) {
                wp_redirect(get_permalink(get_page_by_path('login')) ?: home_url('/login'));
                exit;
            }

            $user = wp_get_current_user();
            $plan = ccpp_get_user_plan($user->ID) ?: 'free';
            ob_start();
            ?>
            <div class="max-w-md mx-auto p-6 bg-white shadow-lg rounded-lg">
                <div class="space-y-4">
                    <p><strong><?php _e('Username:', 'ccpp'); ?></strong> <?php echo esc_html($user->user_login); ?></p>
                    <p><strong><?php _e('Email:', 'ccpp'); ?></strong> <?php echo esc_html($user->user_email); ?></p>
                    <p><strong><?php _e('Plan:', 'ccpp'); ?></strong> <?php echo esc_html(ucfirst($plan)); ?></p>
                    <div class="space-y-2">
                        <a href="<?php echo esc_url(get_permalink(get_page_by_path('user-profile')) ?: home_url('/user-profile')); ?>" class="block p-2 bg-blue-500 text-white rounded-lg text-center hover:bg-blue-600"><?php _e('Edit Profile', 'ccpp'); ?></a>
                        <a href="<?php echo esc_url(get_permalink(get_page_by_path('password-reset')) ?: home_url('/password-reset')); ?>" class="block p-2 bg-blue-500 text-white rounded-lg text-center hover:bg-blue-600"><?php _e('Change Password', 'ccpp'); ?></a>
                        <a href="<?php echo esc_url(wp_logout_url(home_url())); ?>" class="block p-2 bg-red-500 text-white rounded-lg text-center hover:bg-red-600"><?php _e('Log Out', 'ccpp'); ?></a>
                    </div>
                </div>
            </div>
            <?php
            return ob_get_clean();
        } catch (Exception $e) {
            error_log('CCPP: Account shortcode error: ' . $e->getMessage());
            return '<div class="text-red-500 p-4 bg-red-100 rounded-lg">' . esc_html__('Failed to load account details.', 'ccpp') . '</div>';
        }
    }

    public function ajax_update_account() {
        try {
            check_ajax_referer('ccpp_auth_nonce', 'nonce');
            $user_id = get_current_user_id();
            $new_password = $_POST['new_password'] ?? '';
            $confirm_password = $_POST['confirm_password'] ?? '';

            if (empty($new_password) || empty($confirm_password)) {
                wp_send_json_error(['message' => __('Please fill in all password fields.', 'ccpp')]);
            }

            if ($new_password !== $confirm_password) {
                wp_send_json_error(['message' => __('Passwords do not match.', 'ccpp')]);
            }

            wp_set_password($new_password, $user_id);

            global $wpdb;
            $wpdb->insert(
                $wpdb->prefix . 'ccpp_logs',
                [
                    'user_id' => $user_id,
                    'ip_address' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
                    'attempt_type' => 'password_reset',
                    'attempt_time' => current_time('mysql'),
                ],
                ['%d', '%s', '%s', '%s']
            );

            wp_send_json_success(['message' => __('Password updated successfully.', 'ccpp')]);
        } catch (Exception $e) {
            error_log('CCPP: AJAX update account error: ' . $e->getMessage());
            wp_send_json_error(['message' => __('An error occurred during account update.', 'ccpp')]);
        }
    }

    public function logout_shortcode() {
        try {
            if (!is_user_logged_in()) {
                return '<div class="text-red-500 p-4 bg-red-100 rounded-lg">' . esc_html__('You are not logged in.', 'ccpp') . '</div>';
            }

            wp_logout();
            wp_redirect(home_url());
            exit;
        } catch (Exception $e) {
            error_log('CCPP: Logout shortcode error: ' . $e->getMessage());
            return '<div class="text-red-500 p-4 bg-red-100 rounded-lg">' . esc_html__('Failed to log out.', 'ccpp') . '</div>';
        }
    }

    public function member_directory_shortcode() {
        try {
            if (!get_option('ccpp_member_directory_enabled', '1')) {
                return '<div class="text-red-500 p-4 bg-red-100 rounded-lg">' . esc_html__('Member directory is disabled.', 'ccpp') . '</div>';
            }

            $users = get_users(['meta_key' => 'ccpp_status', 'meta_value' => 'approved']);
            ob_start();
            ?>
            <div class="max-w-4xl mx-auto p-6 bg-white shadow-lg rounded-lg">
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <?php if ($users) : ?>
                        <?php foreach ($users as $user) : ?>
                            <div class="p-4 bg-gray-100 rounded-lg">
                                <strong class="block text-lg font-semibold"><?php echo esc_html($user->display_name); ?></strong>
                                <p class="text-gray-700"><?php echo esc_html($user->user_email); ?></p>
                            </div>
                        <?php endforeach; ?>
                    <?php else : ?>
                        <p class="text-center text-gray-700"><?php _e('No members found.', 'ccpp'); ?></p>
                    <?php endif; ?>
                </div>
            </div>
            <?php
            return ob_get_clean();
        } catch (Exception $e) {
            error_log('CCPP: Member directory shortcode error: ' . $e->getMessage());
            return '<div class="text-red-500 p-4 bg-red-100 rounded-lg">' . esc_html__('Failed to load member directory.', 'ccpp') . '</div>';
        }
    }

    public function handle_password_reset() {
        try {
            if (!isset($_GET['key']) || !isset($_GET['login'])) {
                return;
            }

            $key = sanitize_text_field($_GET['key']);
            $login = sanitize_text_field($_GET['login']);
            $user = check_password_reset_key($key, $login);

            if (is_wp_error($user)) {
                wp_die(__('Invalid or expired password reset link.', 'ccpp'));
            }

            if (isset($_POST['new_password']) && isset($_POST['confirm_password'])) {
                $new_password = $_POST['new_password'];
                $confirm_password = $_POST['confirm_password'];

                if (empty($new_password) || empty($confirm_password)) {
                    wp_die(__('Please fill in all password fields.', 'ccpp'));
                }

                if ($new_password !== $confirm_password) {
                    wp_die(__('Passwords do not match.', 'ccpp'));
                }

                reset_password($user, $new_password);

                global $wpdb;
                $wpdb->insert(
                    $wpdb->prefix . 'ccpp_logs',
                    [
                        'user_id' => $user->ID,
                        'ip_address' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
                        'attempt_type' => 'password_reset',
                        'attempt_time' => current_time('mysql'),
                    ],
                    ['%d', '%s', '%s', '%s']
                );

                wp_redirect(add_query_arg('ccpp_reset', 'success', get_permalink(get_page_by_path('login')) ?: home_url('/login')));
                exit;
            }

            ob_start();
            ?>
            <div class="max-w-md mx-auto p-6 bg-white shadow-lg rounded-lg">
                <form method="post" class="space-y-4">
                    <div>
                        <label for="new_password" class="block text-sm font-medium text-gray-700"><?php _e('New Password', 'ccpp'); ?></label>
                        <input type="password" name="new_password" id="new_password" class="w-full p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
                    </div>
                    <div>
                        <label for="confirm_password" class="block text-sm font-medium text-gray-700"><?php _e('Confirm Password', 'ccpp'); ?></label>
                        <input type="password" name="confirm_password" id="confirm_password" class="w-full p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
                    </div>
                    <div>
                        <input type="submit" value="<?php _e('Reset Password', 'ccpp'); ?>" class="w-full p-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600">
                    </div>
                </form>
            </div>
            <?php
            echo ob_get_clean();
            exit;
        } catch (Exception $e) {
            error_log('CCPP: Handle password reset error: ' . $e->getMessage());
            wp_die(__('An error occurred during password reset.', 'ccpp'));
        }
    }
}
?>