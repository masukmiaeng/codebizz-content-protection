<?php
if (!defined('ABSPATH')) {
    exit;
}

class CCPP_Frontend {
    public function init() {
        try {
            add_filter('the_content', [$this, 'restrict_content']);
            add_action('wp_enqueue_scripts', [$this, 'enqueue_scripts']);
        } catch (Exception $e) {
            error_log('CCPP: Frontend init error: ' . $e->getMessage());
        }
    }

    public function enqueue_scripts() {
        try {
            wp_enqueue_script('ccpp-frontend-script', CCPP_URL . 'assets/js/frontend.js', ['jquery'], CCPP_VERSION, true);
        } catch (Exception $e) {
            error_log('CCPP: Frontend enqueue scripts error: ' . $e->getMessage());
        }
    }

    public function restrict_content($content) {
        try {
            if (!is_singular('post') || !in_the_loop() || !is_main_query()) {
                return $content;
            }

            if (!get_option('ccpp_protection_enabled', '1')) {
                return $content;
            }

            $post_id = get_the_ID();
            $access_level = get_post_meta($post_id, 'ccpp_access_level', true) ?: 'free';
            $protect_by_password = get_post_meta($post_id, 'ccpp_protect_by_password', true);
            $content_password = get_post_meta($post_id, 'ccpp_content_password', true);
            $post_payment_enabled = get_post_meta($post_id, 'ccpp_post_payment_enabled', true);
            $post_payment_amount = floatval(get_post_meta($post_id, 'ccpp_post_payment_amount', true));
            $require_lifetime_plan = get_post_meta($post_id, 'ccpp_require_lifetime_plan', true);
            $lifetime_plan_level = get_post_meta($post_id, 'ccpp_lifetime_plan_level', true);

            // Check if user has access via password
            $transient_key = 'ccpp_access_' . $post_id . '_' . get_current_user_id();
            $has_password_access = get_transient($transient_key);

            // Check if user has paid for this post
            $post_access_key = 'ccpp_post_access_' . $post_id . '_' . get_current_user_id();
            $has_post_access = get_transient($post_access_key);

            // Admins can always view content
            if (current_user_can('manage_options')) {
                return $content;
            }

            // If post-specific payment is enabled and user hasn't paid
            if ($post_payment_enabled === '1' && $post_payment_amount > 0 && !$has_post_access) {
                ob_start();
                ?>
                <div class="ccpp-content-locker p-6 bg-gray-100 rounded-lg">
                    <p class="text-red-500 font-semibold"><?php _e('This post requires a one-time payment to access.', 'ccpp'); ?></p>
                    <button id="ccpp-paypal-button-post-<?php echo esc_attr($post_id); ?>" class="mt-4 p-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 w-full" data-post-id="<?php echo esc_attr($post_id); ?>" data-amount="<?php echo esc_attr($post_payment_amount); ?>"><?php _e('Pay $' . number_format($post_payment_amount, 2) . ' to Unlock', 'ccpp'); ?></button>
                </div>
                <script src="https://www.paypal.com/sdk/js?client-id=<?php echo esc_js(get_option('ccpp_paypal_client_id', '')); ?>¤cy=USD"></script>
                <script>
                    paypal.Buttons({
                        createOrder: function(data, actions) {
                            return actions.order.create({
                                purchase_units: [{
                                    amount: {
                                        value: '<?php echo esc_js($post_payment_amount); ?>',
                                        currency_code: 'USD'
                                    }
                                }]
                            });
                        },
                        onApprove: function(data, actions) {
                            return actions.order.capture().then(function(details) {
                                jQuery.post(ccpp_frontend.ajax_url, {
                                    action: 'ccpp_process_post_payment',
                                    nonce: ccpp_frontend.nonce,
                                    order_id: details.id,
                                    payer_id: details.payer.payer_id,
                                    post_id: '<?php echo esc_js($post_id); ?>'
                                }, function(response) {
                                    if (response.success) {
                                        alert('Payment successful! Post unlocked.');
                                        location.reload();
                                    } else {
                                        alert('Payment failed: ' + response.data.message);
                                    }
                                });
                            });
                        },
                        onError: function(err) {
                            console.error('PayPal error:', err);
                            alert('An error occurred during payment.');
                        }
                    }).render('#ccpp-paypal-button-post-<?php echo esc_attr($post_id); ?>');
                </script>
                <?php
                return $this->split_content($content) . ob_get_clean();
            }

            // If password protection is enabled and user hasn't unlocked it
            if ($protect_by_password === '1' && $content_password && !$has_password_access) {
                ob_start();
                ?>
                <div class="ccpp-content-locker p-6 bg-gray-100 rounded-lg">
                    <p class="text-red-500 font-semibold"><?php _e('This content is password protected.', 'ccpp'); ?></p>
                    <form id="ccpp-password-form-<?php echo esc_attr($post_id); ?>" class="space-y-4 mt-4">
                        <input type="hidden" name="post_id" value="<?php echo esc_attr($post_id); ?>">
                        <input type="password" name="password" placeholder="<?php _e('Enter password', 'ccpp'); ?>" class="w-full p-2 border rounded-lg" required>
                        <button type="submit" class="w-full p-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600"><?php _e('Unlock Content', 'ccpp'); ?></button>
                    </form>
                    <div id="ccpp-password-message-<?php echo esc_attr($post_id); ?>" class="hidden p-4 mt-4 rounded-lg"></div>
                </div>
                <?php
                return $this->split_content($content) . ob_get_clean();
            }

            // Check user's plan
            $user_plan = ccpp_get_user_plan() ?: 'free';
            $plans_hierarchy = ['free' => 0, 'silver' => 1, 'premium' => 2, 'platinum' => 3];
            $user_level = $plans_hierarchy[$user_plan] ?? 0;
            $required_level = $plans_hierarchy[$access_level] ?? 0;

            // Check if lifetime plan is required
            if ($require_lifetime_plan === '1') {
                $required_lifetime_level = $plans_hierarchy[$lifetime_plan_level] ?? 1; // Default to Silver
                global $wpdb;
                $table = $wpdb->prefix . 'ccpp_subscriptions';
                $user_id = get_current_user_id();
                $has_lifetime_plan = $wpdb->get_var($wpdb->prepare(
                    "SELECT COUNT(*) FROM $table WHERE user_id = %d AND plan = %s AND billing_cycle = 'lifetime' AND status = 'active'",
                    $user_id,
                    $lifetime_plan_level
                ));

                if (!$has_lifetime_plan || $user_level < $required_lifetime_level) {
                    $subscribe_url = get_permalink(get_option('ccpp_page_pricing')) ?: home_url('/pricing');
                    $message = sprintf(__('This post requires a %s Lifetime plan ($%s).', 'ccpp'), ucfirst($lifetime_plan_level), $lifetime_plan_level === 'silver' ? '200' : ($lifetime_plan_level === 'premium' ? '350' : '500'));
                    ob_start();
                    ?>
                    <div class="ccpp-content-locker p-6 bg-gray-100 rounded-lg">
                        <p class="text-red-500 font-semibold"><?php echo esc_html($message); ?></p>
                        <a href="<?php echo esc_url($subscribe_url); ?>" class="inline-block mt-4 p-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600"><?php _e('Get Lifetime Plan', 'ccpp'); ?></a>
                    </div>
                    <?php
                    return $this->split_content($content) . ob_get_clean();
                }
            }

            // Regular access level check
            if ($user_level >= $required_level) {
                return $content;
            }

            // Display restriction message
            $message = sprintf(__('Only for %s subscribers.', 'ccpp'), ucfirst($access_level));
            $subscribe_url = get_permalink(get_option('ccpp_page_pricing')) ?: home_url('/pricing');
            ob_start();
            ?>
            <div class="ccpp-content-locker p-6 bg-gray-100 rounded-lg">
                <p class="text-red-500 font-semibold"><?php echo esc_html($message); ?></p>
                <a href="<?php echo esc_url($subscribe_url); ?>" class="inline-block mt-4 p-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600"><?php _e('Subscribe Now', 'ccpp'); ?></a>
            </div>
            <?php
            return $this->split_content($content) . ob_get_clean();
        } catch (Exception $e) {
            error_log('CCPP: Restrict content error: ' . $e->getMessage());
            return $content;
        }
    }

    private function split_content($content) {
        $paragraphs = explode('</p>', $content);
        if (count($paragraphs) > 1) {
            return $paragraphs[0] . '</p>';
        }
        return $content;
    }
}
?>